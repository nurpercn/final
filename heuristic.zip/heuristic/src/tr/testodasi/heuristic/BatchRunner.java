package tr.testodasi.heuristic;
 
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
 
/**
 * Runs multiple instances defined in a single CSV and writes one summary CSV.
 *
 * <p>Expected CSV header columns (case-insensitive):
 * - instanceId
 * - projectId
 * - dueDateDays
 * - needsVolt
 * - test matrix columns as in {@link Data#MATRIX_COLUMNS} (0/1)
 *
 * <p>Optional columns:
 * - samples (per-project initial samples)
 * - initialSamples (per-instance default samples)
 * - enableSampleIncrease, sampleMax, sampleSearchMaxEvals
 * - maxOuterIterations, maxVnsShakes, stage2LocalMaxPasses, topBottomRebalanceCount
 * - enableRoomLS, roomLSMaxEvals, roomLSSwap, roomLSMove, roomLSIncludeSample
 * - validate
 */
public final class BatchRunner {
  private static final int VNS_PROGRESS_STEP = 200;
  private static final ThreadLocal<DecimalFormat> RATIO_FMT = ThreadLocal.withInitial(() -> {
    DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.ROOT);
    DecimalFormat df = new DecimalFormat("0.###", symbols);
    df.setGroupingUsed(false);
    return df;
  });

  private BatchRunner() {}
 
  public static void run(Path instancesCsv, Path outCsv, boolean verbose) throws IOException {
    run(instancesCsv, outCsv, null, false, verbose, false, HeuristicSolver.DEFAULT_RANDOM_SEED);
  }
 
  /**
   * @param detailsDir if non-null, writes additional detailed CSVs into this directory
   * @param includeSchedule if true, also writes the full schedule rows (can be large)
   */
  public static void run(Path instancesCsv, Path outCsv, Path detailsDir, boolean includeSchedule, boolean verbose) throws IOException {
    run(instancesCsv, outCsv, detailsDir, includeSchedule, verbose, false, HeuristicSolver.DEFAULT_RANDOM_SEED);
  }

  /**
   * @param detailsDir if non-null, writes additional detailed CSVs into this directory
   * @param includeSchedule if true, also writes the full schedule rows (can be large)
   * @param printScheduleEvals if true, prints schedule evaluation counts per instance
   */
  public static void run(Path instancesCsv, Path outCsv, Path detailsDir, boolean includeSchedule, boolean verbose, boolean printScheduleEvals) throws IOException {
    run(instancesCsv, outCsv, detailsDir, includeSchedule, verbose, printScheduleEvals, HeuristicSolver.DEFAULT_RANDOM_SEED);
  }

  /**
   * @param detailsDir if non-null, writes additional detailed CSVs into this directory
   * @param includeSchedule if true, also writes the full schedule rows (can be large)
   * @param printScheduleEvals if true, prints schedule evaluation counts per instance
   * @param randomSeed random seed used by VNS shake moves; null means non-deterministic
   */
  public static void run(
      Path instancesCsv,
      Path outCsv,
      Path detailsDir,
      boolean includeSchedule,
      boolean verbose,
      boolean printScheduleEvals,
      Long randomSeed
  ) throws IOException {
    Objects.requireNonNull(instancesCsv);
    Objects.requireNonNull(outCsv);
 
    List<String> lines = Files.readAllLines(instancesCsv);
    if (lines.isEmpty()) throw new IllegalArgumentException("instances CSV is empty: " + instancesCsv);
 
    List<String> header = parseCsvLine(lines.get(0));
    Map<String, Integer> col = new HashMap<>();
    for (int i = 0; i < header.size(); i++) {
      col.put(norm(header.get(i)), i);
    }
 
    require(col, "instanceid");
    require(col, "projectid");
    require(col, "duedatedays");
    require(col, "needsvolt");
    for (String mc : Data.MATRIX_COLUMNS) require(col, norm(mc));
 
    Map<String, List<List<String>>> rowsByInstance = new LinkedHashMap<>();
    for (int li = 1; li < lines.size(); li++) {
      String raw = lines.get(li).trim();
      if (raw.isEmpty()) continue;
      if (raw.startsWith("#")) continue;
      List<String> row = parseCsvLine(lines.get(li));
      String inst = get(row, col, "instanceid");
      if (inst == null || inst.isBlank()) throw new IllegalArgumentException("Missing instanceId at line " + (li + 1));
      rowsByInstance.computeIfAbsent(inst, k -> new ArrayList<>()).add(row);
    }
    if (rowsByInstance.isEmpty()) throw new IllegalArgumentException("No instance rows found in: " + instancesCsv);
 
    DataSnapshot snap = DataSnapshot.capture();
    Files.createDirectories(outCsv.toAbsolutePath().getParent() == null ? Path.of(".") : outCsv.toAbsolutePath().getParent());
 
    BufferedWriter projW = null;
    BufferedWriter envW = null;
    BufferedWriter schedW = null;
    BufferedWriter vnsW = null;
    BufferedWriter checkpointW = null;
    if (detailsDir != null) {
      Files.createDirectories(detailsDir);
      projW = Files.newBufferedWriter(detailsDir.resolve("batch_project_results.csv"));
      envW = Files.newBufferedWriter(detailsDir.resolve("batch_chamber_env.csv"));
      if (includeSchedule) {
        schedW = Files.newBufferedWriter(detailsDir.resolve("batch_schedule.csv"));
      }
      vnsW = Files.newBufferedWriter(detailsDir.resolve("batch_vns_trace.csv"));
      // Keep a non-batch-compatible filename too, so users can always find checkpoint CSV.
      checkpointW = Files.newBufferedWriter(detailsDir.resolve("vns_checkpoints.csv"));
 
      projW.write("instanceId,iteration,projectId,dueDateDays,needsVolt,samples,completionDay,lateness");
      projW.newLine();
      envW.write("instanceId,iteration,chamberId,stations,voltageCapable,humidityAdjustable,envTempC,envHumidity");
      envW.newLine();
      if (schedW != null) {
        schedW.write("instanceId,iteration,projectId,testId,category,tempC,humidity,durationDays,needsVoltage,dueDateDays,samples,sampleIdx,chamberId,stationIdx,startDay,endDay");
        schedW.newLine();
      }
      vnsW.write("instanceId,iteration,vnsIteration,kind,totalLateness,totalSamples,stage2ElapsedMs,shakeRatio");
      vnsW.newLine();
      checkpointW.write("instanceId,checkpointGlobalVnsIteration,globalVnsIterationAtEvent,outerIteration,outerVnsIteration,globalBestTotalLateness,globalBestTotalSamples,currentTotalLateness,currentTotalSamples,stage2ElapsedMs,lastShakeKind,shakeRatio");
      checkpointW.newLine();
    }
 
    try (BufferedWriter w = Files.newBufferedWriter(outCsv)) {
      // lateProjects eklendi
      w.write("instanceId,projects,bestIteration,totalLateness,lateProjects,totalSamples,horizonDays,avgStationUtil,maxStationUtil,avgChamberUtil," +
          "stage1RuntimeMs," +
          "stage2PreShakeTotalLateness,stage2PreShakeTotalSamples,stage2PreShakeRuntimeMs,stage2DidShake,stage2RuntimeMs," +
          "stage2Passes,stage2Evals,stage2Shakes,stage2VnsRuntimeMs," +
          "vnsEntered,vnsEntryIteration,vnsEntryLateness,vnsExitIteration,vnsExitLateness,vnsImproved,vnsStopReason," +
          "maxOuterIterations,maxVnsShakes,stage2LocalMaxPasses,topBottomRebalanceCount," +
          "scheduleEvals," +
          "runtimeMs");
      w.newLine();
 
      for (var e : rowsByInstance.entrySet()) {
        String instanceId = e.getKey();
        List<List<String>> rows = e.getValue();
 
        snap.restore(); // reset global knobs each instance
        InstanceParams ip = InstanceParams.from(rows, col);
        ip.applyToData();
 
        List<Project> projects = buildProjectsFromRows(rows, col, ip);
 
        long t0 = System.currentTimeMillis();
        final BufferedWriter traceWriter = vnsW;
        final BufferedWriter checkpointsWriter = checkpointW;
        final Map<Integer, Integer> lastOuterVnsIteration = new HashMap<>();
        final int[] globalVnsState = new int[] {0};
        final int[] nextGlobalCheckpoint = new int[] {VNS_PROGRESS_STEP};
        final int[] globalBest = new int[] {Integer.MAX_VALUE, Integer.MAX_VALUE}; // lateness, samples
        HeuristicSolver.ProgressListener listener = new HeuristicSolver.ProgressListener() {
          @Override
          public void onStage1Done(int outerIteration, long stage1RuntimeMs) {
            // Keep console output light; Stage1 is recorded in summary (best iteration).
            if (verbose) {
              System.out.println("PROGRESS: instance=" + instanceId + " iter=" + outerIteration +
                  " stage1Ms=" + stage1RuntimeMs);
            }
          }

          @Override
          public void onOuterIterationLocalResult(
              int outerIteration,
              int totalLateness,
              int totalSamples,
              long stage1RuntimeMs,
              long stage2RuntimeMs,
              int stage2Passes,
              int stage2Evals
          ) {
            System.out.println("PROGRESS: instance=" + instanceId + " iter=" + outerIteration +
                " OUTER_LOCAL totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " stage1Ms=" + stage1RuntimeMs +
                " stage2Ms=" + stage2RuntimeMs +
                " stage2Passes=" + stage2Passes +
                " stage2Evals=" + stage2Evals);
          }

          @Override
          public void onStage2PreShake(int outerIteration, int totalLateness, int totalSamples, long runtimeMs) {
            System.out.println("PROGRESS: instance=" + instanceId + " iter=" + outerIteration +
                " VNS_PRE totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " preMs=" + runtimeMs);
            if (traceWriter != null) {
              try {
                traceWriter.write(csv(instanceId) + "," + outerIteration + ",0,PRESHAKE," +
                    totalLateness + "," + totalSamples + "," + runtimeMs);
                traceWriter.newLine();
                traceWriter.flush();
              } catch (IOException ex) {
                throw new RuntimeException(ex);
              }
            }
          }

          @Override
          public void onVnsIteration(int outerIteration, int vnsIteration, String kind, int totalLateness, int totalSamples, long stage2ElapsedMs, double shakeRatio) {
            System.out.println("PROGRESS: instance=" + instanceId + " iter=" + outerIteration +
                " VNS#" + vnsIteration + " kind=" + kind +
                " totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " stage2Ms=" + stage2ElapsedMs +
                " ratio=" + fmt(shakeRatio));
            if (traceWriter != null) {
              try {
                traceWriter.write(csv(instanceId) + "," + outerIteration + "," + vnsIteration + "," + kind + "," +
                    totalLateness + "," + totalSamples + "," + stage2ElapsedMs + "," + fmt(shakeRatio));
                traceWriter.newLine();
                traceWriter.flush();
              } catch (IOException ex) {
                throw new RuntimeException(ex);
              }
            }

            if (checkpointsWriter == null) return;

            int prevOuterVns = lastOuterVnsIteration.getOrDefault(outerIteration, 0);
            int delta = Math.max(0, vnsIteration - prevOuterVns);
            lastOuterVnsIteration.put(outerIteration, vnsIteration);
            globalVnsState[0] += delta;

            if (totalLateness < globalBest[0] || (totalLateness == globalBest[0] && totalSamples < globalBest[1])) {
              globalBest[0] = totalLateness;
              globalBest[1] = totalSamples;
            }

            while (globalVnsState[0] >= nextGlobalCheckpoint[0]) {
              try {
                checkpointsWriter.write(
                    csv(instanceId) + "," +
                        nextGlobalCheckpoint[0] + "," +
                        globalVnsState[0] + "," +
                        outerIteration + "," +
                        vnsIteration + "," +
                        globalBest[0] + "," +
                        globalBest[1] + "," +
                        totalLateness + "," +
                        totalSamples + "," +
                        stage2ElapsedMs + "," +
                        (kind == null ? "" : kind) + "," +
                        fmt(shakeRatio)
                );
                checkpointsWriter.newLine();
              } catch (IOException ex) {
                throw new RuntimeException(ex);
              }
              nextGlobalCheckpoint[0] += VNS_PROGRESS_STEP;
            }
            try {
              checkpointsWriter.flush();
            } catch (IOException ex) {
              throw new RuntimeException(ex);
            }
          }
        };

        HeuristicSolver solver = new HeuristicSolver(verbose, listener, randomSeed);
        List<Solution> sols = solver.solveWithProjects(projects);
        Solution best = sols.stream().min(java.util.Comparator.comparingInt(s -> s.totalLateness)).orElseThrow();
        long t1 = System.currentTimeMillis();
        long scheduleEvals = solver.getScheduleEvalCount();
 
        Utilization.Summary util = Utilization.compute(best);
        int totalSamples = 0;
        for (Project p : best.projects) totalSamples += p.samples;
 
        int lateProjects = countLateProjects(best);
 
        int outerIterations = sols.size();
        int vnsEnteredCount = 0;
        int totalVnsShakes = 0;
        int maxVnsShakesInSingleOuter = 0;
        int noImprovementStopShakes = 0;
        int firstVnsEntryIter = -1;
        int lastVnsExitIter = -1;
        int firstVnsEntryLateness = -1;
        int lastVnsExitLateness = -1;
        for (Solution s : sols) {
          if (!s.stage2DidShake) continue;
          vnsEnteredCount++;
          totalVnsShakes += Math.max(0, s.stage2Shakes);
          maxVnsShakesInSingleOuter = Math.max(maxVnsShakesInSingleOuter, Math.max(0, s.stage2Shakes));
          if (firstVnsEntryIter < 0) {
            firstVnsEntryIter = s.iteration;
            firstVnsEntryLateness = s.stage2PreShakeTotalLateness;
          }
          lastVnsExitIter = s.iteration;
          lastVnsExitLateness = s.totalLateness;
          if (s.stage2Shakes >= Data.MAX_VNS_SHAKES && s.totalLateness >= s.stage2PreShakeTotalLateness) {
            noImprovementStopShakes = s.stage2Shakes;
          }
        }
        String vnsEntered = vnsEnteredCount > 0 ? "true" : "false";
        String vnsEntryIteration = firstVnsEntryIter > 0 ? Integer.toString(firstVnsEntryIter) : "";
        String vnsEntryLateness = firstVnsEntryLateness >= 0 ? Integer.toString(firstVnsEntryLateness) : "";
        String vnsExitIteration = lastVnsExitIter > 0 ? Integer.toString(lastVnsExitIter) : "";
        String vnsExitLateness = lastVnsExitLateness >= 0 ? Integer.toString(lastVnsExitLateness) : "";
        String vnsImproved = (vnsEnteredCount > 0 && firstVnsEntryLateness >= 0 && best.totalLateness < firstVnsEntryLateness)
            ? "true" : "false";
        String vnsStopReason = noImprovementStopShakes > 0 ? "max_vns_no_improvement" : (vnsEnteredCount > 0 ? "improved_then_outer" : "not_entered");

        w.write(csv(instanceId) + "," +
            best.projects.size() + "," +
            best.iteration + "," +
            best.totalLateness + "," +
            lateProjects + "," +
            totalSamples + "," +
            util.horizonDays + "," +
            fmt(util.avgStationUtilization) + "," +
            fmt(util.maxStationUtilization) + "," +
            fmt(util.avgChamberUtilization) + "," +
            best.stage1RuntimeMs + "," +
            best.stage2PreShakeTotalLateness + "," +
            best.stage2PreShakeTotalSamples + "," +
            best.stage2PreShakeRuntimeMs + "," +
            best.stage2DidShake + "," +
            best.stage2RuntimeMs + "," +
            best.stage2Passes + "," +
            best.stage2Evals + "," +
            best.stage2Shakes + "," +
            best.stage2VnsRuntimeMs + "," +
            outerIterations + "," +
            vnsEnteredCount + "," +
            totalVnsShakes + "," +
            maxVnsShakesInSingleOuter + "," +
            noImprovementStopShakes + "," +
            vnsEntered + "," +
            vnsEntryIteration + "," +
            vnsEntryLateness + "," +
            vnsExitIteration + "," +
            vnsExitLateness + "," +
            vnsImproved + "," +
            csv(vnsStopReason) + "," +
            Data.MAX_OUTER_ITERATIONS + "," +
            Data.MAX_VNS_SHAKES + "," +
            Data.STAGE2_LOCAL_MAX_PASSES + "," +
            Data.TOP_BOTTOM_REBALANCE_COUNT + "," +
            scheduleEvals + "," +
            (t1 - t0));
        w.newLine();
        w.flush(); // stream results as each instance completes
 
        if (projW != null) {
          // project results
          Map<String, Project> projectById = new HashMap<>();
          for (Project p : best.projects) projectById.put(p.id, p);
          for (ProjectResult r : best.results) {
            Project p = projectById.get(r.projectId);
            projW.write(csv(instanceId) + "," + best.iteration + "," + csv(r.projectId) + "," +
                (p != null ? p.dueDateDays : r.dueDate) + "," +
                (p != null && p.needsVoltage) + "," +
                (p != null ? p.samples : "") + "," +
                r.completionDay + "," +
                r.lateness);
            projW.newLine();
          }
          projW.flush();
 
          // chamber env assignment
          for (ChamberSpec c : Data.CHAMBERS) {
            Env env = best.chamberEnv.get(c.id);
            envW.write(csv(instanceId) + "," + best.iteration + "," + c.id + "," + c.stations + "," +
                c.voltageCapable + "," + c.humidityAdjustable + "," +
                (env != null ? env.temperatureC : "") + "," +
                (env != null ? env.humidity : ""));
            envW.newLine();
          }
          envW.flush();
 
          // full schedule (optional)
          if (schedW != null) {
            for (Scheduler.ScheduledJob j : best.schedule) {
              Project p = projectById.get(j.projectId);
              schedW.write(csv(instanceId) + "," + best.iteration + "," +
                  csv(j.projectId) + "," + j.testId + "," + j.category + "," +
                  j.env.temperatureC + "," + j.env.humidity + "," + j.durationDays + "," +
                  (p != null && p.needsVoltage) + "," + (p != null ? p.dueDateDays : "") + "," + (p != null ? p.samples : "") + "," +
                  j.sampleIdx + "," + j.chamberId + "," + j.stationIdx + "," + j.start + "," + j.end);
              schedW.newLine();
            }
            schedW.flush();
          }
        }
 
        System.out.println("DONE: instance=" + instanceId +
            " projects=" + best.projects.size() +
            " bestIter=" + best.iteration +
            " totalLateness=" + best.totalLateness +
            " lateProjects=" + lateProjects +
            " stage1Ms=" + best.stage1RuntimeMs +
            " preShake=" + best.stage2PreShakeTotalLateness +
            " preShakeMs=" + best.stage2PreShakeRuntimeMs +
            " vnsIters=" + best.stage2Shakes +
            " vnsMs=" + best.stage2VnsRuntimeMs +
            " stage2Ms=" + best.stage2RuntimeMs +
            " runtimeMs=" + (t1 - t0));
        if (printScheduleEvals) {
          System.out.println("SCHEDULE_EVALS: instance=" + instanceId + " evals=" + scheduleEvals);
        }
      }
    } finally {
      if (projW != null) try { projW.close(); } catch (IOException ignored) {}
      if (envW != null) try { envW.close(); } catch (IOException ignored) {}
      if (schedW != null) try { schedW.close(); } catch (IOException ignored) {}
      if (vnsW != null) try { vnsW.close(); } catch (IOException ignored) {}
      if (checkpointW != null) try { checkpointW.close(); } catch (IOException ignored) {}
      snap.restore();
    }
  }
 
  private static int countLateProjects(Solution s) {
    int c = 0;
    for (ProjectResult r : s.results) {
      if (r.lateness > 0) c++;
    }
    return c;
  }
 
  private static List<Project> buildProjectsFromRows(List<List<String>> rows, Map<String, Integer> col, InstanceParams ip) {
    List<Project> projects = new ArrayList<>();
    int defaultSamples = Math.max(Data.MIN_SAMPLES, ip.initialSamples != null ? ip.initialSamples : Data.INITIAL_SAMPLES);
 
    for (List<String> row : rows) {
      String pid = get(row, col, "projectid");
      if (pid == null || pid.isBlank()) throw new IllegalArgumentException("Missing projectId for instanceId=" + get(row, col, "instanceid"));
      int due = parseInt(get(row, col, "duedatedays"), "dueDateDays projectId=" + pid);
      boolean needsVolt = parseBool(get(row, col, "needsvolt"));
 
      Integer perProjectSamples = null;
      if (col.containsKey("samples")) {
        String s = get(row, col, "samples");
        if (s != null && !s.isBlank()) perProjectSamples = parseInt(s, "samples projectId=" + pid);
      }
      int samples = perProjectSamples != null ? perProjectSamples : defaultSamples;
      samples = Math.max(Data.MIN_SAMPLES, Math.min(Data.SAMPLE_MAX, samples));
 
      boolean[] req = new boolean[Data.TESTS.size()];
      for (int ti = 0; ti < Data.MATRIX_COLUMNS.length; ti++) {
        String mc = Data.MATRIX_COLUMNS[ti];
        int v = parseInt(get(row, col, mc), "matrix " + mc + " projectId=" + pid);
        req[ti] = (v == 1);
      }
      projects.add(new Project(pid, due, needsVolt, req, samples));
    }
    return projects;
  }
 
  private static final class InstanceParams {
    final Integer initialSamples;
    final Boolean enableSampleIncrease;
    final Integer sampleMax;
    final Integer sampleSearchMaxEvals;
    final Integer maxOuterIterations;
    final Integer maxVnsShakes;
    final Integer stage2LocalMaxPasses;
    final Integer topBottomRebalanceCount;
 
    final Boolean enableRoomLS;
    final Integer roomLSMaxEvals;
    final Boolean roomLSSwap;
    final Boolean roomLSMove;
    final Boolean roomLSIncludeSample;
 
    final Boolean validate;
 
    private InstanceParams(
        Integer initialSamples,
        Boolean enableSampleIncrease,
        Integer sampleMax,
        Integer sampleSearchMaxEvals,
        Integer maxOuterIterations,
        Integer maxVnsShakes,
        Integer stage2LocalMaxPasses,
        Integer topBottomRebalanceCount,
        Boolean enableRoomLS,
        Integer roomLSMaxEvals,
        Boolean roomLSSwap,
        Boolean roomLSMove,
        Boolean roomLSIncludeSample,
        Boolean validate
    ) {
      this.initialSamples = initialSamples;
      this.enableSampleIncrease = enableSampleIncrease;
      this.sampleMax = sampleMax;
      this.sampleSearchMaxEvals = sampleSearchMaxEvals;
      this.maxOuterIterations = maxOuterIterations;
      this.maxVnsShakes = maxVnsShakes;
      this.stage2LocalMaxPasses = stage2LocalMaxPasses;
      this.topBottomRebalanceCount = topBottomRebalanceCount;
      this.enableRoomLS = enableRoomLS;
      this.roomLSMaxEvals = roomLSMaxEvals;
      this.roomLSSwap = roomLSSwap;
      this.roomLSMove = roomLSMove;
      this.roomLSIncludeSample = roomLSIncludeSample;
      this.validate = validate;
    }
 
    static InstanceParams from(List<List<String>> rows, Map<String, Integer> col) {
      return new InstanceParams(
          firstInt(rows, col, "initialsamples"),
          firstBool(rows, col, "enablesampleincrease"),
          firstInt(rows, col, "samplemax"),
          firstInt(rows, col, "samplesearchmaxevals"),
          firstInt(rows, col, "maxouteriterations"),
          firstInt(rows, col, "maxvnsshakes"),
          firstInt(rows, col, "stage2localmaxpasses"),
          firstInt(rows, col, "topbottomrebalancecount"),
          firstBool(rows, col, "enableroomls"),
          firstInt(rows, col, "roomlsmaxevals"),
          firstBool(rows, col, "roomlsswap"),
          firstBool(rows, col, "roomlsmove"),
          firstBool(rows, col, "roomlsincludesample"),
          firstBool(rows, col, "validate")
      );
    }
 
    void applyToData() {
      if (initialSamples != null) Data.INITIAL_SAMPLES = initialSamples;
      if (enableSampleIncrease != null) Data.ENABLE_SAMPLE_INCREASE = enableSampleIncrease;
      if (sampleMax != null) Data.SAMPLE_MAX = sampleMax;
      if (sampleSearchMaxEvals != null) Data.SAMPLE_SEARCH_MAX_EVALS = sampleSearchMaxEvals;
      if (maxOuterIterations != null) Data.MAX_OUTER_ITERATIONS = maxOuterIterations;
      if (maxVnsShakes != null) Data.MAX_VNS_SHAKES = maxVnsShakes;
      if (stage2LocalMaxPasses != null) Data.STAGE2_LOCAL_MAX_PASSES = stage2LocalMaxPasses;
      if (topBottomRebalanceCount != null) Data.TOP_BOTTOM_REBALANCE_COUNT = topBottomRebalanceCount;
 
      if (enableRoomLS != null) Data.ENABLE_ROOM_LOCAL_SEARCH = enableRoomLS;
      if (roomLSMaxEvals != null) Data.ROOM_LS_MAX_EVALS = roomLSMaxEvals;
      if (roomLSSwap != null) Data.ROOM_LS_ENABLE_SWAP = roomLSSwap;
      if (roomLSMove != null) Data.ROOM_LS_ENABLE_MOVE = roomLSMove;
      if (roomLSIncludeSample != null) Data.ROOM_LS_INCLUDE_SAMPLE_HEURISTIC = roomLSIncludeSample;
 
      if (validate != null) Data.ENABLE_SCHEDULE_VALIDATION = validate;
    }
  }
 
  private static final class DataSnapshot {
    final int initialSamples = Data.INITIAL_SAMPLES;
    final boolean enableSampleIncrease = Data.ENABLE_SAMPLE_INCREASE;
    final int sampleMax = Data.SAMPLE_MAX;
    final int sampleSearchMaxEvals = Data.SAMPLE_SEARCH_MAX_EVALS;
    final int maxOuterIterations = Data.MAX_OUTER_ITERATIONS;
    final int maxVnsShakes = Data.MAX_VNS_SHAKES;
    final int stage2LocalMaxPasses = Data.STAGE2_LOCAL_MAX_PASSES;
    final int topBottomRebalanceCount = Data.TOP_BOTTOM_REBALANCE_COUNT;
 
    final boolean enableRoomLS = Data.ENABLE_ROOM_LOCAL_SEARCH;
    final int roomLSMaxEvals = Data.ROOM_LS_MAX_EVALS;
    final boolean roomLSSwap = Data.ROOM_LS_ENABLE_SWAP;
    final boolean roomLSMove = Data.ROOM_LS_ENABLE_MOVE;
    final boolean roomLSIncludeSample = Data.ROOM_LS_INCLUDE_SAMPLE_HEURISTIC;
    final Data.VnsMode vnsMode = Data.VNS_MODE;
    final Data.VnsStrategy vnsStrategy = Data.VNS_STRATEGY;
    final double vnsShakeRatio = Data.VNS_SHAKE_RATIO;
    final double vnsAdaptiveStage1Ratio = Data.VNS_ADAPTIVE_STAGE1_RATIO;
    final double vnsAdaptiveStage2Ratio = Data.VNS_ADAPTIVE_STAGE2_RATIO;
    final double vnsAdaptiveStage3Ratio = Data.VNS_ADAPTIVE_STAGE3_RATIO;
    final int vnsAdaptiveStage1Shakes = Data.VNS_ADAPTIVE_STAGE1_SHAKES;
    final int vnsAdaptiveStage2Shakes = Data.VNS_ADAPTIVE_STAGE2_SHAKES;
    final int vnsAdaptiveStage3Shakes = Data.VNS_ADAPTIVE_STAGE3_SHAKES;
    final boolean vnsAdaptiveCycleStages = Data.VNS_ADAPTIVE_CYCLE_STAGES;
 
    final boolean validate = Data.ENABLE_SCHEDULE_VALIDATION;
 
    static DataSnapshot capture() { return new DataSnapshot(); }
 
    void restore() {
      Data.INITIAL_SAMPLES = initialSamples;
      Data.ENABLE_SAMPLE_INCREASE = enableSampleIncrease;
      Data.SAMPLE_MAX = sampleMax;
      Data.SAMPLE_SEARCH_MAX_EVALS = sampleSearchMaxEvals;
      Data.MAX_OUTER_ITERATIONS = maxOuterIterations;
      Data.MAX_VNS_SHAKES = maxVnsShakes;
      Data.STAGE2_LOCAL_MAX_PASSES = stage2LocalMaxPasses;
      Data.TOP_BOTTOM_REBALANCE_COUNT = topBottomRebalanceCount;
 
      Data.ENABLE_ROOM_LOCAL_SEARCH = enableRoomLS;
      Data.ROOM_LS_MAX_EVALS = roomLSMaxEvals;
      Data.ROOM_LS_ENABLE_SWAP = roomLSSwap;
      Data.ROOM_LS_ENABLE_MOVE = roomLSMove;
      Data.ROOM_LS_INCLUDE_SAMPLE_HEURISTIC = roomLSIncludeSample;
      Data.VNS_MODE = vnsMode;
      Data.VNS_STRATEGY = vnsStrategy;
      Data.VNS_SHAKE_RATIO = vnsShakeRatio;
      Data.VNS_ADAPTIVE_STAGE1_RATIO = vnsAdaptiveStage1Ratio;
      Data.VNS_ADAPTIVE_STAGE2_RATIO = vnsAdaptiveStage2Ratio;
      Data.VNS_ADAPTIVE_STAGE3_RATIO = vnsAdaptiveStage3Ratio;
      Data.VNS_ADAPTIVE_STAGE1_SHAKES = vnsAdaptiveStage1Shakes;
      Data.VNS_ADAPTIVE_STAGE2_SHAKES = vnsAdaptiveStage2Shakes;
      Data.VNS_ADAPTIVE_STAGE3_SHAKES = vnsAdaptiveStage3Shakes;
      Data.VNS_ADAPTIVE_CYCLE_STAGES = vnsAdaptiveCycleStages;
 
      Data.ENABLE_SCHEDULE_VALIDATION = validate;
    }
  }
 
  // ---- CSV helpers ----
 
  private static String fmt(double x) {
    return String.format(Locale.ROOT, "%.6f", x);
  }
 
  private static void require(Map<String, Integer> col, String name) {
    if (!col.containsKey(name)) throw new IllegalArgumentException("Missing required CSV column: " + name);
  }
 
  private static String norm(String s) {
    if (s == null) return "";
    // Handle UTF-8 BOM that often appears in Excel-exported CSVs on Windows.
    // Example: "\uFEFFinstanceId" would fail required-column checks.
    String x = s;
    if (!x.isEmpty() && x.charAt(0) == '\uFEFF') x = x.substring(1);
    return x.trim().toLowerCase(Locale.ROOT);
  }
 
  private static String get(List<String> row, Map<String, Integer> col, String key) {
    Integer i = col.get(norm(key));
    if (i == null) return null;
    return i < row.size() ? row.get(i).trim() : "";
  }
 
  private static int parseInt(String s, String ctx) {
    if (s == null || s.isBlank()) throw new IllegalArgumentException("Missing int for " + ctx);
    try {
      return Integer.parseInt(s.trim());
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Invalid int for " + ctx + ": " + s);
    }
  }
 
  private static double parseDouble(String s, String ctx) {
    if (s == null || s.isBlank()) throw new IllegalArgumentException("Missing double for " + ctx);
    try {
      return Double.parseDouble(s.trim());
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Invalid double for " + ctx + ": " + s);
    }
  }

  private static boolean parseBool(String s) {
    if (s == null) return false;
    String v = s.trim().toLowerCase(Locale.ROOT);
    return "1".equals(v) || "true".equals(v) || "yes".equals(v) || "y".equals(v);
  }
 
  private static Integer firstInt(List<List<String>> rows, Map<String, Integer> col, String key) {
    if (!col.containsKey(key)) return null;
    for (List<String> r : rows) {
      String v = get(r, col, key);
      if (v != null && !v.isBlank()) return parseInt(v, key);
    }
    return null;
  }
 
  private static Boolean firstBool(List<List<String>> rows, Map<String, Integer> col, String key) {
    if (!col.containsKey(key)) return null;
    for (List<String> r : rows) {
      String v = get(r, col, key);
      if (v != null && !v.isBlank()) return parseBool(v);
    }
    return null;
  }

  private static Double firstDouble(List<List<String>> rows, Map<String, Integer> col, String key) {
    if (!col.containsKey(key)) return null;
    for (List<String> r : rows) {
      String v = get(r, col, key);
      if (v != null && !v.isBlank()) return parseDouble(v, key);
    }
    return null;
  }
 
  // Minimal CSV parser (supports quotes and commas inside quotes).
  private static List<String> parseCsvLine(String line) {
    // Many Excel exports in TR/DE locales use ';' as separator (because ',' is decimal separator).
    // Support both ',' and ';' by choosing delimiter based on the header/content line.
    char delim = ',';
    if (line != null) {
      boolean hasComma = line.indexOf(',') >= 0;
      boolean hasSemi = line.indexOf(';') >= 0;
      if (!hasComma && hasSemi) delim = ';';
    }
 
    List<String> out = new ArrayList<>();
    StringBuilder cur = new StringBuilder();
    boolean inQuotes = false;
    for (int i = 0; i < line.length(); i++) {
      char ch = line.charAt(i);
      if (ch == '"') {
        if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
          cur.append('"');
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch == delim && !inQuotes) {
        out.add(cur.toString());
        cur.setLength(0);
      } else {
        cur.append(ch);
      }
    }
    out.add(cur.toString());
    return out;
  }
 
  private static String csv(String s) {
    if (s == null) return "";
    boolean need = s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r");
    if (!need) return s;
    return "\"" + s.replace("\"", "\"\"") + "\"";
  }
}