
package tr.testodasi.heuristic;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class HeuristicSolver {
  public static final Long DEFAULT_RANDOM_SEED = 42L;

  private final Scheduler scheduler = new Scheduler();
  private final boolean verbose;
  private final ProgressListener listener;
  private final Long randomSeed;
  private Random seededRandom;
  private boolean stoppedByNoVnsImprovement;
  private int stopOuterIteration;
  private int totalVnsShakes;
  private final List<Integer> vnsEnteredOuterIterations = new ArrayList<>();

  public HeuristicSolver() {
    this(false);
  }

  public HeuristicSolver(boolean verbose) {
    this(verbose, null, DEFAULT_RANDOM_SEED);
  }

  public HeuristicSolver(boolean verbose, ProgressListener listener) {
    this(verbose, listener, DEFAULT_RANDOM_SEED);
  }

  public HeuristicSolver(boolean verbose, ProgressListener listener, Long randomSeed) {
    this.verbose = verbose;
    this.listener = listener;
    this.randomSeed = randomSeed;
  }

  public List<Solution> solve() {
    List<Project> projects = Data.buildProjects(Data.INITIAL_SAMPLES);
    return solveWithProjects(projects);
  }

  /** Runs solver using the given project list (for batch/CSV instances). */
  public List<Solution> solveWithProjects(List<Project> projects) {
    Objects.requireNonNull(projects);

    scheduler.resetEvalCount();
    seededRandom = randomSeed != null ? new Random(randomSeed) : null;
    stoppedByNoVnsImprovement = false;
    stopOuterIteration = -1;
    totalVnsShakes = 0;
    vnsEnteredOuterIterations.clear();
    List<Solution> solutions = new ArrayList<>();
    List<Project> current = deepCopy(projects);
    int bestGlobalLateness = Integer.MAX_VALUE;
    int bestGlobalSamples = Integer.MAX_VALUE;
    List<Project> bestGlobalProjects = deepCopy(current);
    Map<String, Env> bestGlobalRoom = null;
    int maxOuter = Math.max(1, Data.MAX_OUTER_ITERATIONS);

    for (int iter = 1; iter <= maxOuter; iter++) {
      final long tStage1Start = System.nanoTime();
      Map<String, Env> room = stage1_assignRooms(current);
      final long stage1RuntimeMs = (System.nanoTime() - tStage1Start) / 1_000_000L;
      if (listener != null) listener.onStage1Done(iter, stage1RuntimeMs);

      if (Data.ENABLE_ROOM_LOCAL_SEARCH) {
        RoomScore base = scoreRoom(room, current);
        Map<String, Env> improvedRoom = improveRoomsByLocalSearch(current, room, base.totalLateness);
        RoomScore after = scoreRoom(improvedRoom, current);
        if (after.totalLateness < base.totalLateness) {
          if (verbose) {
            System.out.println("INFO: Room local-search improved total lateness: " +
                base.totalLateness + " -> " + after.totalLateness);
          }
          room = improvedRoom;
        } else if (verbose) {
          System.out.println("INFO: Room local-search no improvement (baseline=" + base.totalLateness + ")");
        }
      }

      // Stage2 (local search only). VNS is orchestrated at outer-loop level.
      Stage2Result localStage2 = Data.ENABLE_SAMPLE_INCREASE
          ? stage2_increaseSamples(iter, room, current, false)
          : Stage2Result.identity(deepCopy(current));
      List<Project> improved = localStage2.projects;
      Scheduler.EvalResult eval = scheduler.evaluateNoCopy(improved, room);
      int iterSamples = totalSamples(improved);

      int stage2PreShakeTotalLateness = eval.totalLateness;
      int stage2PreShakeTotalSamples = iterSamples;
      long stage2PreShakeRuntimeMs = localStage2.runtimeMs;
      boolean stage2DidShake = false;
      long stage2RuntimeMs = localStage2.runtimeMs;
      int stage2Passes = localStage2.passes;
      int stage2Evals = localStage2.evals;
      int stage2Shakes = 0;
      long stage2VnsRuntimeMs = 0L;

      if (listener != null) {
        listener.onOuterIterationLocalResult(
            iter,
            eval.totalLateness,
            iterSamples,
            stage1RuntimeMs,
            localStage2.runtimeMs,
            localStage2.passes,
            localStage2.evals
        );
      }

      boolean improvedGlobal = isBetter(eval.totalLateness, iterSamples, bestGlobalLateness, bestGlobalSamples);
      if (improvedGlobal) {
        bestGlobalLateness = eval.totalLateness;
        bestGlobalSamples = iterSamples;
        bestGlobalProjects = deepCopy(improved);
        bestGlobalRoom = new LinkedHashMap<>(room);
      }
      boolean improvedForOuter = !Data.ENABLE_SAMPLE_INCREASE || improvedGlobal;
      boolean forceVnsFirstIter = Data.ENABLE_SAMPLE_INCREASE
          && Data.FORCE_VNS_ON_FIRST_ITERATION
          && iter == 1;
      if (Data.ENABLE_SAMPLE_INCREASE && (!improvedGlobal || forceVnsFirstIter)) {
        vnsEnteredOuterIterations.add(iter);
        // VNS always starts from the best solution found so far, not from the current stalled iteration.
        List<Project> vnsStartProjects = deepCopy(bestGlobalProjects);
        Map<String, Env> vnsRoom = bestGlobalRoom != null ? new LinkedHashMap<>(bestGlobalRoom) : new LinkedHashMap<>(room);
        Scheduler.EvalResult vnsStartEval = scheduler.evaluateNoCopy(vnsStartProjects, vnsRoom);
        stage2PreShakeTotalLateness = vnsStartEval.totalLateness;
        stage2PreShakeTotalSamples = totalSamples(vnsStartProjects);
        if (listener != null) {
          listener.onStage2PreShake(iter, stage2PreShakeTotalLateness, stage2PreShakeTotalSamples, stage2PreShakeRuntimeMs);
        }
        List<Double> ratioCandidates = resolveVnsRatioCandidates();
        boolean improvedByAnyVns = false;
        int ratioIdxUsed = -1;
        List<Project> bestVnsProjects = null;
        int bestVnsShakes = 0;
        int bestVnsPasses = 0;
        int bestVnsEvals = 0;
        long totalVnsRuntimeMs = 0L;
        int totalVnsShakesLocal = 0;

        for (int ri = 0; ri < ratioCandidates.size(); ri++) {
          double ratioCandidate = ratioCandidates.get(ri);
          double prevRatio = Data.VNS_SHAKE_RATIO;
          Data.VNS_SHAKE_RATIO = ratioCandidate;
          if (verbose) {
            System.out.println(
                "INFO: VNS ratio phase " + (ri + 1) + "/" + ratioCandidates.size() +
                    " ratio=" + String.format(java.util.Locale.ROOT, "%.3f", ratioCandidate));
          }
          VnsSearchResult vns = runVnsUntilImprovement(
              iter,
              vnsRoom,
              vnsStartProjects,
              stage2PreShakeTotalLateness,
              stage2PreShakeTotalSamples,
              true
          );
          Data.VNS_SHAKE_RATIO = prevRatio;

          stage2DidShake = stage2DidShake || (vns.shakes > 0);
          totalVnsShakesLocal += vns.shakes;
          totalVnsShakes += vns.shakes;
          totalVnsRuntimeMs += vns.runtimeMs;
          stage2Passes += vns.passes;
          stage2Evals += vns.evals;
          bestVnsShakes += vns.shakes;
          bestVnsPasses += vns.passes;
          bestVnsEvals += vns.evals;

          if (vns.improved) {
            improvedByAnyVns = true;
            ratioIdxUsed = ri;
            bestVnsProjects = vns.projects;
            break;
          }
        }
        stage2Shakes = totalVnsShakesLocal;
        stage2VnsRuntimeMs = totalVnsRuntimeMs;
        stage2RuntimeMs += totalVnsRuntimeMs;

        if (improvedByAnyVns && bestVnsProjects != null) {
          improved = bestVnsProjects;
          room = vnsRoom;
          eval = scheduler.evaluateNoCopy(improved, room);
          iterSamples = totalSamples(improved);
          improvedGlobal = isBetter(eval.totalLateness, iterSamples, bestGlobalLateness, bestGlobalSamples);
          improvedForOuter = true;
          if (improvedGlobal) {
            bestGlobalLateness = eval.totalLateness;
            bestGlobalSamples = iterSamples;
            bestGlobalProjects = deepCopy(improved);
            bestGlobalRoom = new LinkedHashMap<>(room);
          }
          if (verbose) {
            System.out.println(
                "INFO: VNS improved with ratio phase " + (ratioIdxUsed + 1) + "/" + ratioCandidates.size() +
                    " after totalShakes=" + stage2Shakes);
          }
        } else {
          stoppedByNoVnsImprovement = true;
          stopOuterIteration = iter;
          improvedForOuter = false;
          if (verbose) {
            System.out.println("INFO: No improvement after " + stage2Shakes + " VNS shakes across all ratio phases. Stopping.");
          }
        }
      }

      solutions.add(new Solution(
          iter,
          eval.totalLateness,
          deepCopy(improved),
          room,
          eval.projectResults,
          eval.schedule,
          stage1RuntimeMs,
          stage2PreShakeTotalLateness,
          stage2PreShakeTotalSamples,
          stage2PreShakeRuntimeMs,
          stage2DidShake,
          stage2RuntimeMs,
          stage2Passes,
          stage2Evals,
          stage2Shakes,
          stage2VnsRuntimeMs
      ));

      if (Data.ENABLE_SCHEDULE_VALIDATION) {
        List<String> violations = Scheduler.validateSchedule(improved, room, eval.schedule);
        if (!violations.isEmpty()) {
          StringBuilder sb = new StringBuilder();
          sb.append("Schedule validation failed (").append(violations.size()).append(" violations). First 20:\n");
          for (int i = 0; i < Math.min(20, violations.size()); i++) {
            sb.append("- ").append(violations.get(i)).append("\n");
          }
          throw new IllegalStateException(sb.toString());
        }
      }

      current = deepCopy(improved);

      if (Data.ENABLE_SAMPLE_INCREASE && !improvedForOuter) {
        break;
      }
    }

    return solutions;
  }

  public long getScheduleEvalCount() {
    return scheduler.getEvalCount();
  }

  public boolean isStoppedByNoVnsImprovement() {
    return stoppedByNoVnsImprovement;
  }

  public int getStopOuterIteration() {
    return stopOuterIteration;
  }

  public int getTotalVnsShakes() {
    return totalVnsShakes;
  }

  public List<Integer> getVnsEnteredOuterIterations() {
    return new ArrayList<>(vnsEnteredOuterIterations);
  }

  private record RoomScore(int totalLateness) {}
  private record ChamberLoad(ChamberSpec chamber, int busyDays, double normalizedBusyDays) {}

  private RoomScore scoreRoom(Map<String, Env> room, List<Project> projects) {
    if (Data.ROOM_LS_INCLUDE_SAMPLE_HEURISTIC) {
      // When used as a scoring subroutine inside room local-search, DO NOT emit progress logs.
      Stage2Result improved = stage2_localOnly(0, room, projects, false, true);
      Scheduler.EvalResult eval = scheduler.evaluateFastNoCopy(improved.projects, room);
      return new RoomScore(eval.totalLateness);
    }
    Scheduler.EvalResult eval = scheduler.evaluateFastNoCopy(projects, room);
    return new RoomScore(eval.totalLateness);
  }

  private Map<String, Env> improveRoomsByLocalSearch(List<Project> projects, Map<String, Env> startRoom, int baseline) {
    int maxEvals = Math.max(10, Data.ROOM_LS_MAX_EVALS);
    Map<String, Env> best = new LinkedHashMap<>(startRoom);
    int bestScore = baseline;

    // demanded env set from current projects
    Set<Env> demanded = new LinkedHashSet<>();
    Set<Env> demandedByVolt = new LinkedHashSet<>();
    for (Project p : projects) {
      for (int ti = 0; ti < Data.TESTS.size(); ti++) {
        if (!p.required[ti]) continue;
        Env env = Data.TESTS.get(ti).env;
        demanded.add(env);
        if (p.needsVoltage) demandedByVolt.add(env);
      }
    }
    if (demanded.isEmpty()) return best;

    int evals = 0;
    boolean improvedAny;
    do {
      improvedAny = false;
      List<ChamberLoad> denseOrder = rankChambersByLoad(projects, best);
      List<ChamberLoad> sparseOrder = new ArrayList<>(denseOrder);
      sparseOrder.sort(
          Comparator.comparingDouble((ChamberLoad x) -> x.normalizedBusyDays)
              .thenComparingInt(x -> x.busyDays)
              .thenComparing(x -> x.chamber.id)
      );

      // SWAP: en yoğun oda ile en boş oda çiftlerini öncelikle dene.
      if (Data.ROOM_LS_ENABLE_SWAP) {
        for (ChamberLoad dense : denseOrder) {
          if (evals >= maxEvals) break;
          for (ChamberLoad sparse : sparseOrder) {
            if (evals >= maxEvals) break;
            if (dense.chamber.id.equals(sparse.chamber.id)) continue;
            if (dense.normalizedBusyDays <= sparse.normalizedBusyDays) continue;
            Env denseEnv = best.get(dense.chamber.id);
            Env sparseEnv = best.get(sparse.chamber.id);
            if (denseEnv == null || sparseEnv == null || denseEnv.equals(sparseEnv)) continue;
            if (!canAssign(dense.chamber, sparseEnv) || !canAssign(sparse.chamber, denseEnv)) continue;

            Map<String, Env> candRoom = new LinkedHashMap<>(best);
            candRoom.put(dense.chamber.id, sparseEnv);
            candRoom.put(sparse.chamber.id, denseEnv);
            if (!isRoomFeasible(candRoom, demanded, demandedByVolt)) continue;
            evals++;
            int s = scoreRoom(candRoom, projects).totalLateness;
            if (s < bestScore) {
              best = candRoom;
              bestScore = s;
              improvedAny = true;
              break;
            }
          }
          if (improvedAny) break;
        }
      }

      // MOVE: en boş odanın ayarını en yoğun odanın env değerine taşı.
      if (!improvedAny && Data.ROOM_LS_ENABLE_MOVE) {
        for (ChamberLoad dense : denseOrder) {
          if (evals >= maxEvals) break;
          Env denseEnv = best.get(dense.chamber.id);
          if (denseEnv == null) continue;
          for (ChamberLoad sparse : sparseOrder) {
            if (evals >= maxEvals) break;
            if (dense.chamber.id.equals(sparse.chamber.id)) continue;
            if (dense.normalizedBusyDays <= sparse.normalizedBusyDays) continue;
            Env sparseEnv = best.get(sparse.chamber.id);
            if (sparseEnv == null || denseEnv.equals(sparseEnv)) continue;
            if (!canAssign(sparse.chamber, denseEnv)) continue;
            Map<String, Env> candRoom = new LinkedHashMap<>(best);
            candRoom.put(sparse.chamber.id, denseEnv);
            if (!isRoomFeasible(candRoom, demanded, demandedByVolt)) continue;
            evals++;
            int s = scoreRoom(candRoom, projects).totalLateness;
            if (s < bestScore) {
              best = candRoom;
              bestScore = s;
              improvedAny = true;
              break;
            }
          }
          if (improvedAny) break;
        }
      }

    } while (improvedAny && evals < maxEvals);

    if (verbose) {
      System.out.println("INFO: Room local-search evals=" + evals + " best=" + bestScore + " baseline=" + baseline);
    }
    return best;
  }

  private static boolean canAssign(ChamberSpec chamber, Env env) {
    if (env.humidity == Humidity.H85 && !chamber.humidityAdjustable) return false;
    return true;
  }

  private List<ChamberLoad> rankChambersByLoad(List<Project> projects, Map<String, Env> room) {
    Scheduler.EvalResult eval = scheduler.evaluateNoCopy(projects, room);
    Map<String, Integer> busyDaysByChamber = new HashMap<>();
    for (Scheduler.ScheduledJob j : eval.schedule) {
      busyDaysByChamber.merge(j.chamberId, j.durationDays, Integer::sum);
    }
    List<ChamberLoad> out = new ArrayList<>(Data.CHAMBERS.size());
    for (ChamberSpec c : Data.CHAMBERS) {
      int busyDays = busyDaysByChamber.getOrDefault(c.id, 0);
      double normalized = busyDays / (double) Math.max(1, c.stations);
      out.add(new ChamberLoad(c, busyDays, normalized));
    }
    out.sort(
        Comparator.comparingDouble((ChamberLoad x) -> x.normalizedBusyDays).reversed()
            .thenComparingInt(x -> x.busyDays).reversed()
            .thenComparing(x -> x.chamber.id)
    );
    return out;
  }

  private static boolean isRoomFeasible(Map<String, Env> room, Set<Env> demanded, Set<Env> demandedByVolt) {
    // (1) each demanded env has at least 1 room
    Map<Env, Integer> count = new HashMap<>();
    Map<Env, Integer> countVoltRooms = new HashMap<>();
    Map<String, ChamberSpec> chamberById = new HashMap<>();
    for (ChamberSpec c : Data.CHAMBERS) chamberById.put(c.id, c);

    for (var e : room.entrySet()) {
      Env env = e.getValue();
      if (env == null) continue;
      ChamberSpec ch = chamberById.get(e.getKey());
      if (ch == null) continue;
      // humidity feasibility
      if (env.humidity == Humidity.H85 && !ch.humidityAdjustable) return false;
      count.merge(env, 1, Integer::sum);
      if (ch.voltageCapable) countVoltRooms.merge(env, 1, Integer::sum);
    }
    for (Env env : demanded) {
      if (count.getOrDefault(env, 0) <= 0) return false;
    }
    // (2) env demanded by voltage projects should have at least 1 voltage-capable room
    for (Env env : demandedByVolt) {
      if (countVoltRooms.getOrDefault(env, 0) <= 0) return false;
    }
    return true;
  }

  private record Stage2Result(
      List<Project> projects,
      int preShakeTotalLateness,
      int preShakeTotalSamples,
      long preShakeRuntimeMs,
      boolean didShake,
      long runtimeMs,
      int passes,
      int evals,
      int shakes,
      long vnsRuntimeMs
  ) {
    static Stage2Result identity(List<Project> projects) {
      int ts = totalSamples(projects);
      return new Stage2Result(projects, -1, ts, -1L, false, -1L, -1, -1, 0, 0L);
    }
  }

  private record VnsSearchResult(
      List<Project> projects,
      boolean improved,
      int passes,
      int evals,
      int shakes,
      long runtimeMs
  ) {}

  private enum VnsDirectionMode {
    DOWN_ONLY,
    UP_ONLY,
    UP_DOWN
  }

  private enum VnsStrategyMode {
    NORMAL,
    ADAPTIVE
  }

  private static final class LatenessInfo {
    final int[] lateness;
    final int[] earlySlack;

    private LatenessInfo(int[] lateness, int[] earlySlack) {
      this.lateness = lateness;
      this.earlySlack = earlySlack;
    }

    boolean isLate(int idx) {
      return lateness[idx] > 0;
    }

    static LatenessInfo fromResults(List<Project> projects, Map<String, Integer> idxById, List<ProjectResult> results) {
      int n = projects.size();
      int[] late = new int[n];
      int[] slack = new int[n];
      for (ProjectResult r : results) {
        Integer idx = idxById.get(r.projectId);
        if (idx == null) continue;
        int completion = r.completionDay;
        int due = r.dueDate;
        int l = Math.max(0, completion - due);
        int s = Math.max(0, due - completion);
        late[idx] = l;
        slack[idx] = s;
      }
      return new LatenessInfo(late, slack);
    }
  }

  private boolean isBetter(int lateness, int samples, int bestLateness, int bestSamples) {
    return lateness < bestLateness || (lateness == bestLateness && samples < bestSamples);
  }

  private Scheduler.EvalResult evalForStage2(
      List<Project> projects,
      Map<String, Env> room,
      boolean needsProjectResults
  ) {
    return needsProjectResults
        ? scheduler.evaluateResultsNoScheduleNoCopy(projects, room)
        : scheduler.evaluateFastNoCopy(projects, room);
  }

  private Stage2Result stage2_localOnly(
      int outerIteration,
      Map<String, Env> room,
      List<Project> startProjects,
      boolean emitProgress,
      boolean allowPlusMinusTwo
  ) {
    List<Project> current = deepCopy(startProjects);
    for (Project p : current) {
      if (p.samples < Data.MIN_SAMPLES) p.samples = Data.MIN_SAMPLES;
      if (p.samples > Data.SAMPLE_MAX) p.samples = Data.SAMPLE_MAX;
    }

    final long tStart = System.nanoTime();
    boolean needsProjectResults = true;
    Map<String, Integer> idxById = new HashMap<>();
    for (int i = 0; i < current.size(); i++) idxById.put(current.get(i).id, i);

    Scheduler.EvalResult baseEval = evalForStage2(current, room, needsProjectResults);
    int evals = 1;
    int passes = 0;
    boolean improvedAny;
    int maxPasses = Math.max(1, Data.STAGE2_LOCAL_MAX_PASSES);

    do {
      improvedAny = false;
      passes++;

      // Single-project local search with full neighborhood: +1,+2,-1,-2
      for (int i = 0; i < current.size(); i++) {
        Project p = current.get(i);
        int curSamples = p.samples;
        int bestSamples = curSamples;
        Scheduler.EvalResult bestEval = baseEval;

        int[] deltas;
        if (allowPlusMinusTwo) {
          deltas = (curSamples <= Data.MIN_SAMPLES)
              ? new int[]{+1, +2}
              : new int[]{+1, +2, -1, -2};
        } else {
          deltas = (curSamples <= Data.MIN_SAMPLES)
              ? new int[]{+1}
              : new int[]{+1, -1};
        }

        for (int d : deltas) {
          int ns = curSamples + d;
          if (ns < Data.MIN_SAMPLES || ns > Data.SAMPLE_MAX || ns == curSamples) continue;
          p.samples = ns;
          Scheduler.EvalResult e = scheduler.evaluateFastNoCopy(current, room);
          evals++;
          p.samples = curSamples;
          if (e.totalLateness < bestEval.totalLateness ||
              (e.totalLateness == bestEval.totalLateness && ns < bestSamples)) {
            bestEval = e;
            bestSamples = ns;
          }
        }

        if (bestSamples != curSamples &&
            (bestEval.totalLateness < baseEval.totalLateness ||
                (bestEval.totalLateness == baseEval.totalLateness && bestSamples < curSamples))) {
          p.samples = bestSamples;
          baseEval = evalForStage2(current, room, needsProjectResults);
          evals++;
          improvedAny = true;
        }
      }

      // Keep existing model step: 10 worst +1 and 10 best -1 (paired by rank).
      List<Project> beforePairing = deepCopy(current);
      Scheduler.EvalResult beforePairingEval = baseEval;
      LatenessInfo info = LatenessInfo.fromResults(current, idxById, baseEval.projectResults);
      boolean changedPairing = applyTopBottomRebalance(current, info, Data.TOP_BOTTOM_REBALANCE_COUNT);
      if (changedPairing) {
        Scheduler.EvalResult e = evalForStage2(current, room, needsProjectResults);
        evals++;
        if (e.totalLateness <= baseEval.totalLateness) {
          if (e.totalLateness < baseEval.totalLateness ||
              totalSamples(current) <= totalSamples(startProjects)) {
            baseEval = e;
            improvedAny = true;
          }
        } else {
          // revert if worse
          current = beforePairing;
          baseEval = beforePairingEval;
        }
      }
    } while (improvedAny && passes < maxPasses);

    final long runtimeMs = (System.nanoTime() - tStart) / 1_000_000L;
    if (emitProgress && listener != null) {
      listener.onStage2PreShake(outerIteration, baseEval.totalLateness, totalSamples(current), runtimeMs);
    }
    return new Stage2Result(
        current,
        baseEval.totalLateness,
        totalSamples(current),
        runtimeMs,
        false,
        runtimeMs,
        passes,
        evals,
        0,
        0L
    );
  }

  private boolean applyTopBottomRebalance(List<Project> current, LatenessInfo info, int pairCount) {
    List<Integer> lateIdx = new ArrayList<>();
    List<Integer> earlyIdx = new ArrayList<>();
    for (int i = 0; i < current.size(); i++) {
      if (info.lateness[i] > 0) lateIdx.add(i);
      else if (info.earlySlack[i] > 0) earlyIdx.add(i);
    }
    if (lateIdx.isEmpty() || earlyIdx.isEmpty()) return false;

    lateIdx.sort((a, b) -> Integer.compare(info.lateness[b], info.lateness[a]));
    earlyIdx.sort((a, b) -> Integer.compare(info.earlySlack[b], info.earlySlack[a]));
    int k = Math.min(Math.max(1, pairCount), Math.min(lateIdx.size(), earlyIdx.size()));

    boolean changed = false;
    for (int t = 0; t < k; t++) {
      Project late = current.get(lateIdx.get(t));
      Project early = current.get(earlyIdx.get(t));
      if (late.samples < Data.SAMPLE_MAX) {
        late.samples += 1;
        changed = true;
      }
      if (early.samples > Data.MIN_SAMPLES) {
        early.samples -= 1;
        changed = true;
      }
    }
    return changed;
  }

  private VnsSearchResult runVnsUntilImprovement(
      int outerIteration,
      Map<String, Env> room,
      List<Project> startProjects,
      int entryLateness,
      int entrySamples,
      boolean emitProgress
  ) {
    final long tStart = System.nanoTime();
    List<Project> best = deepCopy(startProjects);
    Scheduler.EvalResult bestEval = scheduler.evaluateNoCopy(best, room);
    int bestSamples = totalSamples(best);
    int shakes = 0;
    int passes = 0;
    int evals = 1;
    boolean nextShakeDown = true;
    VnsDirectionMode vnsMode = parseVnsDirectionMode(Data.VNS_MODE);
    VnsStrategyMode strategyMode = parseVnsStrategyMode(Data.VNS_STRATEGY);
    int bestSeenLateness = bestEval.totalLateness;
    int bestSeenSamples = bestSamples;

    int maxShakes = Math.max(0, Data.MAX_VNS_SHAKES);
    while (shakes < maxShakes) {
      boolean useDown = switch (vnsMode) {
        case DOWN_ONLY -> true;
        case UP_ONLY -> false;
        case UP_DOWN -> nextShakeDown;
      };
      double ratio = ratioForShakeIndex(strategyMode, shakes, maxShakes);
      // VNS principle requested: each shake starts from current VNS-best baseline.
      List<Project> candidate = deepCopy(best);
      boolean didShake = useDown
          ? tryShakeDownToMin(room, candidate, null, Integer.MAX_VALUE, evals, ratio)
          : tryShakeUpToSix(room, candidate, null, Integer.MAX_VALUE, evals, ratio);
      String kind = useDown ? "DOWN" : "UP";
      if (vnsMode == VnsDirectionMode.UP_DOWN) {
        nextShakeDown = !nextShakeDown;
      }
      if (!didShake) {
        shakes++;
        if (emitProgress && listener != null) {
          listener.onVnsIteration(
              outerIteration,
              shakes,
              kind,
              bestEval.totalLateness,
              bestSamples,
              (System.nanoTime() - tStart) / 1_000_000L,
              ratio
          );
        }
        continue;
      }
      shakes++;
      Stage2Result local = stage2_localOnly(outerIteration, room, candidate, false, !Data.VNS_DISABLE_PLUS_MINUS_TWO);
      candidate = local.projects;
      passes += local.passes;
      evals += local.evals;
      Scheduler.EvalResult candidateEval = scheduler.evaluateNoCopy(candidate, room);
      evals++;
      int candidateSamples = totalSamples(candidate);
      boolean improvedWithinRun = isBetter(candidateEval.totalLateness, candidateSamples, bestSeenLateness, bestSeenSamples);
      if (improvedWithinRun) {
        best = candidate;
        bestEval = candidateEval;
        bestSamples = candidateSamples;
        bestSeenLateness = bestEval.totalLateness;
        bestSeenSamples = bestSamples;
      }
      if (emitProgress && listener != null) {
        listener.onVnsIteration(
            outerIteration,
            shakes,
            kind,
            candidateEval.totalLateness,
            candidateSamples,
            (System.nanoTime() - tStart) / 1_000_000L,
            ratio
        );
      }
      // Optional early-exit: stop VNS as soon as it improves entry baseline.
      if (Data.VNS_EXIT_ON_FIRST_IMPROVEMENT &&
          isBetter(bestEval.totalLateness, bestSamples, entryLateness, entrySamples)) {
        return new VnsSearchResult(best, true, passes, evals, shakes, (System.nanoTime() - tStart) / 1_000_000L);
      }
    }

    boolean improved = isBetter(bestEval.totalLateness, bestSamples, entryLateness, entrySamples);
    return new VnsSearchResult(best, improved, passes, evals, shakes, (System.nanoTime() - tStart) / 1_000_000L);
  }

  private static VnsDirectionMode parseVnsDirectionMode(Data.VnsMode mode) {
    if (mode == null) return VnsDirectionMode.UP_DOWN;
    return switch (mode) {
      case DOWN_ONLY -> VnsDirectionMode.DOWN_ONLY;
      case UP_ONLY -> VnsDirectionMode.UP_ONLY;
      case BOTH -> VnsDirectionMode.UP_DOWN;
    };
  }

  private static VnsStrategyMode parseVnsStrategyMode(Data.VnsStrategy mode) {
    if (mode == null) return VnsStrategyMode.NORMAL;
    return switch (mode) {
      case NORMAL -> VnsStrategyMode.NORMAL;
      case ADAPTIVE -> VnsStrategyMode.ADAPTIVE;
    };
  }

  private static double ratioForShakeIndex(VnsStrategyMode mode, int completedShakes, int maxShakes) {
    if (mode == VnsStrategyMode.NORMAL) {
      return clamp(Data.VNS_SHAKE_RATIO, 0.0, 1.0);
    }
    if (Data.VNS_ADAPTIVE_CYCLE_STAGES) {
      // Cyclic sequence requested: 0.20 -> 0.30 -> 0.40 -> repeat
      int idx = Math.max(0, completedShakes) % 3;
      if (idx == 0) return clamp(Data.VNS_ADAPTIVE_STAGE1_RATIO, 0.0, 1.0);
      if (idx == 1) return clamp(Data.VNS_ADAPTIVE_STAGE2_RATIO, 0.0, 1.0);
      return clamp(Data.VNS_ADAPTIVE_STAGE3_RATIO, 0.0, 1.0);
    }
    // Phase-based adaptive schedule:
    // - first N1 shakes  -> stage1 ratio
    // - next N2 shakes   -> stage2 ratio
    // - remaining shakes -> stage3 ratio
    int phase1 = Math.max(0, Data.VNS_ADAPTIVE_STAGE1_SHAKES);
    int phase2 = Math.max(0, Data.VNS_ADAPTIVE_STAGE2_SHAKES);
    int idx = Math.max(0, completedShakes);
    if (idx < phase1) return clamp(Data.VNS_ADAPTIVE_STAGE1_RATIO, 0.0, 1.0);
    if (idx < phase1 + phase2) return clamp(Data.VNS_ADAPTIVE_STAGE2_RATIO, 0.0, 1.0);
    return clamp(Data.VNS_ADAPTIVE_STAGE3_RATIO, 0.0, 1.0);
  }

  private static double clamp(double x, double lo, double hi) {
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
  }

  private static List<Double> resolveVnsRatioCandidates() {
    List<Double> out = new ArrayList<>();
    // Fallback ratio sequence applies only in NORMAL mode.
    if (Data.VNS_STRATEGY == Data.VnsStrategy.NORMAL && Data.VNS_ESCALATE_ON_NO_IMPROVEMENT) {
      double[] seq = Data.VNS_NO_IMPROVEMENT_RATIOS;
      if (seq != null) {
        for (double r : seq) addRatioIfMissing(out, r);
      }
    }
    if (out.isEmpty()) {
      out.add(clamp(Data.VNS_SHAKE_RATIO, 0.0, 1.0));
    }
    return out;
  }

  private static void addRatioIfMissing(List<Double> ratios, double raw) {
    double r = clamp(raw, 0.0, 1.0);
    for (double e : ratios) {
      if (Math.abs(e - r) <= 1e-9) return;
    }
    ratios.add(r);
  }

  private Stage2Result stage2_increaseSamples(int outerIteration, Map<String, Env> room, List<Project> startProjects, boolean emitProgress) {
    // Before VNS, keep full neighborhood (+1,+2,-1,-2).
    return stage2_localOnly(outerIteration, room, startProjects, emitProgress, true);
  }

  // ---- Stage2 helpers (shake moves) ----

  // These two fields are a small workaround to avoid threading an object through the loop.
  // They are only used inside stage2_increaseSamples call chain.
  private Scheduler.EvalResult lastShakeEval;
  private int lastShakeEvals;

  private static int totalSamples(List<Project> ps) {
    int sum = 0;
    for (Project p : ps) sum += p.samples;
    return sum;
  }

  private int nextRandomInt(int boundExclusive) {
    if (boundExclusive <= 0) {
      throw new IllegalArgumentException("boundExclusive must be > 0");
    }
    if (seededRandom != null) {
      return seededRandom.nextInt(boundExclusive);
    }
    return ThreadLocalRandom.current().nextInt(boundExclusive);
  }

  private boolean tryShakeDownToMin(
      Map<String, Env> room,
      List<Project> current,
      Scheduler.EvalResult baseEval,
      int evalBudget,
      int evals,
      double shakeRatio
  ) {
    if (evals >= evalBudget) return false;
    int k = Math.max(1, (int) Math.ceil(current.size() * clamp(shakeRatio, 0.0, 1.0)));

    List<Integer> idxs = new ArrayList<>();
    for (int i = 0; i < current.size(); i++) {
      if (current.get(i).samples > Data.MIN_SAMPLES) idxs.add(i);
    }
    if (idxs.isEmpty()) return false;
    // Randomly select projects (uniform, without replacement).
    for (int i = idxs.size() - 1; i > 0; i--) {
      int j = nextRandomInt(i + 1);
      int tmp = idxs.get(i);
      idxs.set(i, idxs.get(j));
      idxs.set(j, tmp);
    }

    List<Project> cand = deepCopy(current);
    int changed = 0;
    for (int t = 0; t < idxs.size() && changed < k; t++) {
      int i = idxs.get(t);
      if (cand.get(i).samples > Data.MIN_SAMPLES) {
        cand.get(i).samples = Data.MIN_SAMPLES;
        changed++;
      }
    }
    if (changed == 0) return false;

    Scheduler.EvalResult e = scheduler.evaluateFastNoCopy(cand, room);
    evals++;
    current.clear();
    current.addAll(cand);
    lastShakeEval = e;
    lastShakeEvals = evals;
    if (verbose) {
      System.out.println("INFO: Stage2 shake DOWN => set " + changed + " projects to " + Data.MIN_SAMPLES +
          " totalLateness=" + e.totalLateness);
    }
    return true;
  }

  private boolean tryShakeUpToSix(
      Map<String, Env> room,
      List<Project> current,
      Scheduler.EvalResult baseEval,
      int evalBudget,
      int evals,
      double shakeRatio
  ) {
    if (evals >= evalBudget) return false;
    int target = Data.VNS_SAMPLE_MAX;
    if (target < Data.MIN_SAMPLES) target = Data.MIN_SAMPLES;
    int k = Math.max(1, (int) Math.ceil(current.size() * clamp(shakeRatio, 0.0, 1.0)));

    List<Integer> idxs = new ArrayList<>();
    for (int i = 0; i < current.size(); i++) {
      if (current.get(i).samples < target) idxs.add(i);
    }
    if (idxs.isEmpty()) return false;
    // Randomly select projects (uniform, without replacement).
    for (int i = idxs.size() - 1; i > 0; i--) {
      int j = nextRandomInt(i + 1);
      int tmp = idxs.get(i);
      idxs.set(i, idxs.get(j));
      idxs.set(j, tmp);
    }

    List<Project> cand = deepCopy(current);
    int changed = 0;
    for (int t = 0; t < idxs.size() && changed < k; t++) {
      int i = idxs.get(t);
      if (cand.get(i).samples < target) {
        cand.get(i).samples = target;
        changed++;
      }
    }
    if (changed == 0) return false;

    Scheduler.EvalResult e = scheduler.evaluateFastNoCopy(cand, room);
    evals++;
    current.clear();
    current.addAll(cand);
    lastShakeEval = e;
    lastShakeEvals = evals;
    if (verbose) {
      System.out.println("INFO: Stage2 shake UP => set " + changed + " projects to " + target +
          " totalLateness=" + e.totalLateness);
    }
    return true;
  }

  /**
   * Aşama 1: Oda set değerlerini belirle (sıcaklık/nem sabit kalır).
   *
   * Amaç:
   * - Tüm iş yükünü (env bazında jobDays) ODALAR arasında tek bir global dengeleme ile dağıt.
   * - Voltaj gerektiren iş yükü için voltaj-capable odalarda env kapasitesi ayır (en az 1 volt oda / volt-env).
   * - 85% nem isteyen env sadece humAdj odalara atanabilir.
   *
   * Not: Burada job'ları tek tek odaya atamıyoruz; her oda 1 env'e sabitleniyor.
   * Scheduler daha sonra bu oda/env set değerleri üzerinde job'ları istasyonlara yerleştiriyor.
   */
  private Map<String, Env> stage1_assignRooms(List<Project> projects) {
    Objects.requireNonNull(projects);

    Map<Env, Long> demandTotal = new HashMap<>();
    Map<Env, Long> demandVolt = new HashMap<>();

    // İş listesi -> env bazlı toplam iş yükü (jobCount * durationDays).
    // Bu set sadece gerçekten talep olan env'leri içerir (dengeyi bozan gereksiz atamaları engeller).
    Set<Env> demandedEnvs = new LinkedHashSet<>();

    for (Project p : projects) {
      for (int ti = 0; ti < Data.TESTS.size(); ti++) {
        if (!p.required[ti]) continue;
        TestDef t = Data.TESTS.get(ti);

        int jobs = 1;
        if (t.category == TestCategory.PULLDOWN) jobs = p.samples;

        long w = (long) jobs * (long) t.durationDays;
        // Pulldown için ekstra ağırlık kullanılmıyor.
        demandTotal.merge(t.env, w, Long::sum);
        if (p.needsVoltage) demandVolt.merge(t.env, w, Long::sum);
        demandedEnvs.add(t.env);
      }
    }

    if (demandedEnvs.isEmpty()) {
      throw new IllegalStateException("No demanded environments; check project test matrix.");
    }

    // Hangi env'lerde voltaj talebi var?
    Set<Env> demandedVoltEnvs = new LinkedHashSet<>();
    for (Env env : demandedEnvs) {
      if (demandVolt.getOrDefault(env, 0L) > 0) demandedVoltEnvs.add(env);
    }

    // Total/volt station budgets (for proportional targets)
    int totalStationsAll = 0;
    int totalStationsVoltCapable = 0;
    for (ChamberSpec c : Data.CHAMBERS) {
      totalStationsAll += c.stations;
      if (c.voltageCapable) totalStationsVoltCapable += c.stations;
    }
    long sumDemandTotal = 0;
    long sumDemandVolt = 0;
    for (Env env : demandedEnvs) sumDemandTotal += Math.max(0L, demandTotal.getOrDefault(env, 0L));
    for (Env env : demandedVoltEnvs) sumDemandVolt += Math.max(0L, demandVolt.getOrDefault(env, 0L));
    if (sumDemandTotal <= 0) {
      throw new IllegalStateException("Total demand is zero; cannot assign rooms.");
    }

    Map<Env, Double> targetStationsTotal = new HashMap<>();
    for (Env env : demandedEnvs) {
      double frac = demandTotal.getOrDefault(env, 0L) / (double) sumDemandTotal;
      targetStationsTotal.put(env, frac * totalStationsAll);
    }
    Map<Env, Double> targetStationsVolt = new HashMap<>();
    for (Env env : demandedEnvs) {
      if (sumDemandVolt <= 0 || demandVolt.getOrDefault(env, 0L) <= 0) {
        targetStationsVolt.put(env, 0.0);
      } else {
        double frac = demandVolt.getOrDefault(env, 0L) / (double) sumDemandVolt;
        targetStationsVolt.put(env, frac * totalStationsVoltCapable);
      }
    }

    // Exact (mathematical) assignment: solve the balancing objective optimally under constraints,
    // then let Stage-3 local search further improve true schedule objective if enabled.
    List<Env> envList = new ArrayList<>(demandedEnvs);
    envList.sort(Comparator.comparingInt((Env e) -> e.temperatureC).thenComparing(e -> e.humidity.toString()));

    boolean[] demandedVolt = new boolean[envList.size()];
    double[] tTot = new double[envList.size()];
    double[] tVolt = new double[envList.size()];
    for (int i = 0; i < envList.size(); i++) {
      Env e = envList.get(i);
      demandedVolt[i] = demandedVoltEnvs.contains(e);
      tTot[i] = targetStationsTotal.getOrDefault(e, 0.0);
      tVolt[i] = targetStationsVolt.getOrDefault(e, 0.0);
    }

    double wVolt = 2.0;
    return RoomAssignmentOptimizer.solveExact(Data.CHAMBERS, envList, demandedVolt, tTot, tVolt, wVolt);
  }

  private static double deltaObjectiveIfAssign(
      Env env,
      ChamberSpec chamber,
      Map<Env, Double> targetStationsTotal,
      Map<Env, Double> targetStationsVolt,
      Map<Env, Integer> assignedStationsTotal,
      Map<Env, Integer> assignedStationsVolt
  ) {
    // Objective = SSE(total stations vs target) + wVolt * SSE(volt stations vs targetVolt)
    // Delta computed only for the chosen env (others unchanged).
    double wVolt = 2.0;

    double tTot = targetStationsTotal.getOrDefault(env, 0.0);
    int aTot = assignedStationsTotal.getOrDefault(env, 0);
    double beforeTot = aTot - tTot;
    double afterTot = (aTot + chamber.stations) - tTot;
    double delta = (afterTot * afterTot) - (beforeTot * beforeTot);

    if (chamber.voltageCapable) {
      double tV = targetStationsVolt.getOrDefault(env, 0.0);
      int aV = assignedStationsVolt.getOrDefault(env, 0);
      double beforeV = aV - tV;
      double afterV = (aV + chamber.stations) - tV;
      delta += wVolt * ((afterV * afterV) - (beforeV * beforeV));
    }
    return delta;
  }

  private static void assign(
      Map<String, Env> assignment,
      ChamberSpec chamber,
      Env env,
      Map<Env, Integer> assignedStationsTotal,
      Map<Env, Integer> assignedStationsVolt,
      Map<Env, Integer> roomCount,
      Map<Env, Integer> voltRoomCount
  ) {
    assignment.put(chamber.id, env);
    assignedStationsTotal.merge(env, chamber.stations, Integer::sum);
    roomCount.merge(env, 1, Integer::sum);
    if (chamber.voltageCapable) {
      assignedStationsVolt.merge(env, chamber.stations, Integer::sum);
      voltRoomCount.merge(env, 1, Integer::sum);
    }
  }

  private static List<Project> deepCopy(List<Project> ps) {
    List<Project> out = new ArrayList<>();
    for (Project p : ps) out.add(p.copy());
    return out;
  }

  public interface ProgressListener {
    /** Stage1 (setpoint assignment) completed for given outer iteration. */
    default void onStage1Done(int outerIteration, long stage1RuntimeMs) {}

    /** Stage2 local-only result before VNS decision (for real-time outer iteration tracing). */
    default void onOuterIterationLocalResult(
        int outerIteration,
        int totalLateness,
        int totalSamples,
        long stage1RuntimeMs,
        long stage2RuntimeMs,
        int stage2Passes,
        int stage2Evals
    ) {}

    /** Stage2 pre-shake local optimum captured for given outer iteration. */
    default void onStage2PreShake(int outerIteration, int totalLateness, int totalSamples, long runtimeMs) {}

    /** One VNS (shake) iteration completed for given outer iteration. */
    default void onVnsIteration(int outerIteration, int vnsIteration, String kind, int totalLateness, int totalSamples, long stage2ElapsedMs) {}

    /** One VNS (shake) iteration completed with explicit shake ratio. */
    default void onVnsIteration(
        int outerIteration,
        int vnsIteration,
        String kind,
        int totalLateness,
        int totalSamples,
        long stage2ElapsedMs,
        double shakeRatio
    ) {
      onVnsIteration(outerIteration, vnsIteration, kind, totalLateness, totalSamples, stage2ElapsedMs);
    }
  }

}