package tr.testodasi.heuristic;
 
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;
 
public final class Main {
  private static final int VNS_PROGRESS_STEP = 200;
  private static final long DEFAULT_SEED = 42L;
  private record VnsEventRow(
      int globalVnsIterationAtEvent,
      int outerIteration,
      int outerVnsIteration,
      String eventType,
      String shakeKind,
      double shakeRatio,
      int currentTotalLateness,
      int currentTotalSamples,
      long stage2ElapsedMs,
      int globalBestTotalLateness,
      int globalBestTotalSamples
  ) {}
  private record VnsCheckpointRow(
      int checkpointGlobalVnsIteration,
      int globalVnsIterationAtEvent,
      int outerIteration,
      int outerVnsIteration,
      int globalBestTotalLateness,
      int globalBestTotalSamples,
      int currentTotalLateness,
      int currentTotalSamples,
      long stage2ElapsedMs,
      String lastShakeKind,
      double shakeRatio
  ) {}

  public static void main(String[] args) {
    boolean verbose = false;
    Long randomSeed = DEFAULT_SEED;
    String dumpProjectId = null;
    boolean dumpFirst10 = false;
    String csvDir = null;
    boolean csvFlag = false;
    boolean diagnose = false;
    boolean printScheduleEvals = false;
    String batchPath = null;
    String batchOut = null;
    String batchDetailsDir = null;
    boolean batchSchedule = false;
 
    for (int idx = 0; idx < args.length; idx++) {
      String a = args[idx];
      if ("--help".equalsIgnoreCase(a) || "-h".equalsIgnoreCase(a) || "-?".equalsIgnoreCase(a)) {
        printHelp();
        return;
      }
 
      if (a != null && startsWithIgnoreCase(a, "--batch=")) {
        batchPath = a.substring("--batch=".length()).trim();
      } else if ("--batch".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          batchPath = args[idx + 1].trim();
          idx++;
        }
      }
 
      if (a != null && startsWithIgnoreCase(a, "--batchout=")) {
        batchOut = a.substring("--batchout=".length()).trim();
      } else if ("--batchOut".equalsIgnoreCase(a) || "--batchout".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          batchOut = args[idx + 1].trim();
          idx++;
        }
      }
 
      if (a != null && (startsWithIgnoreCase(a, "--batchdetails=") || startsWithIgnoreCase(a, "--batchdetaildir="))) {
        int p = a.indexOf('=');
        batchDetailsDir = p >= 0 ? a.substring(p + 1).trim() : null;
      } else if ("--batchDetails".equalsIgnoreCase(a) || "--batchDetailDir".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          batchDetailsDir = args[idx + 1].trim();
          idx++;
        }
      }
 
      if (a != null && startsWithIgnoreCase(a, "--batchschedule=")) {
        String v = a.substring("--batchschedule=".length()).trim();
        batchSchedule = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      } else if ("--batchSchedule".equalsIgnoreCase(a)) {
        batchSchedule = true;
      }
 
      if ("--verbose".equalsIgnoreCase(a) || "-v".equalsIgnoreCase(a)) {
        verbose = true;
      }
 
      if (a != null && a.startsWith("--dumpProject=")) {
        dumpProjectId = a.substring("--dumpProject=".length()).trim();
      }
 
      if ("--dumpFirst10".equalsIgnoreCase(a)) {
        dumpFirst10 = true;
      }
 
      if ("--diagnose".equalsIgnoreCase(a) || "--diag".equalsIgnoreCase(a)) {
        diagnose = true;
      }
 
      if ("--scheduleEvals".equalsIgnoreCase(a) || "--schedevals".equalsIgnoreCase(a)) {
        printScheduleEvals = true;
      }

      // CSV arg parsing (case-insensitive, supports both --csvDir=path and --csvDir path)
      if (a != null && startsWithIgnoreCase(a, "--csvdir=")) {
        csvDir = a.substring("--csvdir=".length()).trim();
      } else if (a != null && startsWithIgnoreCase(a, "--csv=")) {
        csvDir = a.substring("--csv=".length()).trim();
      } else if ("--csv".equalsIgnoreCase(a)) {
        csvFlag = true;
      } else if ("--csvDir".equalsIgnoreCase(a) || "--csvdir".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          csvDir = args[idx + 1].trim();
          idx++;
        } else {
          csvFlag = true;
        }
      }
 
      // deprecated flags (ignored)
      if (a != null && a.startsWith("--dispatch=")) {}
      if (a != null && a.startsWith("--mode=")) {}
      if (a != null && a.startsWith("--jobRule=")) {}
      if (a != null && a.startsWith("--jobK=")) {}
      if (a != null && a.startsWith("--atcK=")) {}
      if (a != null && a.startsWith("--orderLS=")) {}
      if (a != null && a.startsWith("--orderLSPasses=")) {}
      if (a != null && a.startsWith("--orderLSWindow=")) {}
      if (a != null && a.startsWith("--orderLSMaxEvals=")) {}
 
      if (a != null && a.startsWith("--roomLS=")) {
        String v = a.substring("--roomLS=".length()).trim();
        Data.ENABLE_ROOM_LOCAL_SEARCH = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      }
      if (a != null && a.startsWith("--roomLSMaxEvals=")) {
        try {
          Data.ROOM_LS_MAX_EVALS = Integer.parseInt(a.substring("--roomLSMaxEvals=".length()).trim());
        } catch (NumberFormatException ignored) {}
      }
      if (a != null && a.startsWith("--roomLSSwap=")) {
        String v = a.substring("--roomLSSwap=".length()).trim();
        Data.ROOM_LS_ENABLE_SWAP = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      }
      if (a != null && a.startsWith("--roomLSMove=")) {
        String v = a.substring("--roomLSMove=".length()).trim();
        Data.ROOM_LS_ENABLE_MOVE = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      }
      if (a != null && a.startsWith("--roomLSIncludeSample=")) {
        String v = a.substring("--roomLSIncludeSample=".length()).trim();
        Data.ROOM_LS_INCLUDE_SAMPLE_HEURISTIC = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      }
      if (a != null && startsWithIgnoreCase(a, "--seed=")) {
        randomSeed = parseSeedArg(a.substring("--seed=".length()), randomSeed);
      } else if ("--seed".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          randomSeed = parseSeedArg(args[idx + 1], randomSeed);
          idx++;
        }
      }
      if (a != null && a.startsWith("--validate=")) {
        String v = a.substring("--validate=".length()).trim();
        Data.ENABLE_SCHEDULE_VALIDATION = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      }
      if (a != null && (startsWithIgnoreCase(a, "--vnsmode=") || startsWithIgnoreCase(a, "-vnsmode="))) {
        int p = a.indexOf('=');
        String raw = p >= 0 ? a.substring(p + 1) : "";
        Data.VNS_MODE = parseVnsModeArg(raw, Data.VNS_MODE);
      } else if ("--vnsMode".equalsIgnoreCase(a) || "-vnsMode".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_MODE = parseVnsModeArg(args[idx + 1], Data.VNS_MODE);
          idx++;
        }
      }
      if (a != null && (startsWithIgnoreCase(a, "--vnsstrategy=") || startsWithIgnoreCase(a, "-vnsstrategy="))) {
        int p = a.indexOf('=');
        String raw = p >= 0 ? a.substring(p + 1) : "";
        Data.VNS_STRATEGY = parseVnsStrategyArg(raw, Data.VNS_STRATEGY);
      } else if ("--vnsStrategy".equalsIgnoreCase(a) || "-vnsStrategy".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_STRATEGY = parseVnsStrategyArg(args[idx + 1], Data.VNS_STRATEGY);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsshakeratio=")) {
        Data.VNS_SHAKE_RATIO = parseDoubleOrDefault(a.substring("--vnsshakeratio=".length()), Data.VNS_SHAKE_RATIO);
      } else if ("--vnsShakeRatio".equalsIgnoreCase(a) || "-vnsShakeRatio".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_SHAKE_RATIO = parseDoubleOrDefault(args[idx + 1], Data.VNS_SHAKE_RATIO);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsfallbackratios=")) {
        String raw = a.substring("--vnsfallbackratios=".length());
        Data.VNS_NO_IMPROVEMENT_RATIOS = parseDoubleArrayOrDefault(raw, Data.VNS_NO_IMPROVEMENT_RATIOS);
      } else if ("--vnsFallbackRatios".equalsIgnoreCase(a) || "-vnsFallbackRatios".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_NO_IMPROVEMENT_RATIOS = parseDoubleArrayOrDefault(args[idx + 1], Data.VNS_NO_IMPROVEMENT_RATIOS);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsfallbackonnoimprove=")) {
        Data.VNS_ESCALATE_ON_NO_IMPROVEMENT =
            parseBoolOrDefault(a.substring("--vnsfallbackonnoimprove=".length()), Data.VNS_ESCALATE_ON_NO_IMPROVEMENT);
      } else if ("--vnsFallbackOnNoImprove".equalsIgnoreCase(a) || "-vnsFallbackOnNoImprove".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          Data.VNS_ESCALATE_ON_NO_IMPROVEMENT =
              parseBoolOrDefault(args[idx + 1], Data.VNS_ESCALATE_ON_NO_IMPROVEMENT);
          idx++;
        } else {
          Data.VNS_ESCALATE_ON_NO_IMPROVEMENT = true;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage1ratio=")) {
        Data.VNS_ADAPTIVE_STAGE1_RATIO = parseDoubleOrDefault(a.substring("--vnsadaptivestage1ratio=".length()), Data.VNS_ADAPTIVE_STAGE1_RATIO);
      } else if ("--vnsAdaptiveStage1Ratio".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE1_RATIO = parseDoubleOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE1_RATIO);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage2ratio=")) {
        Data.VNS_ADAPTIVE_STAGE2_RATIO = parseDoubleOrDefault(a.substring("--vnsadaptivestage2ratio=".length()), Data.VNS_ADAPTIVE_STAGE2_RATIO);
      } else if ("--vnsAdaptiveStage2Ratio".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE2_RATIO = parseDoubleOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE2_RATIO);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage3ratio=")) {
        Data.VNS_ADAPTIVE_STAGE3_RATIO = parseDoubleOrDefault(a.substring("--vnsadaptivestage3ratio=".length()), Data.VNS_ADAPTIVE_STAGE3_RATIO);
      } else if ("--vnsAdaptiveStage3Ratio".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE3_RATIO = parseDoubleOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE3_RATIO);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage1shakes=")) {
        Data.VNS_ADAPTIVE_STAGE1_SHAKES = parseIntOrDefault(a.substring("--vnsadaptivestage1shakes=".length()), Data.VNS_ADAPTIVE_STAGE1_SHAKES);
      } else if ("--vnsAdaptiveStage1Shakes".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE1_SHAKES = parseIntOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE1_SHAKES);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage2shakes=")) {
        Data.VNS_ADAPTIVE_STAGE2_SHAKES = parseIntOrDefault(a.substring("--vnsadaptivestage2shakes=".length()), Data.VNS_ADAPTIVE_STAGE2_SHAKES);
      } else if ("--vnsAdaptiveStage2Shakes".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE2_SHAKES = parseIntOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE2_SHAKES);
          idx++;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsadaptivestage3shakes=")) {
        Data.VNS_ADAPTIVE_STAGE3_SHAKES = parseIntOrDefault(a.substring("--vnsadaptivestage3shakes=".length()), Data.VNS_ADAPTIVE_STAGE3_SHAKES);
      } else if ("--vnsAdaptiveStage3Shakes".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          Data.VNS_ADAPTIVE_STAGE3_SHAKES = parseIntOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_STAGE3_SHAKES);
          idx++;
        }
      }
      if (a != null && (startsWithIgnoreCase(a, "--vnsadaptivecycle=") || startsWithIgnoreCase(a, "-vnsadaptivecycle="))) {
        int eq = a.indexOf('=');
        String raw = eq >= 0 ? a.substring(eq + 1) : "";
        Data.VNS_ADAPTIVE_CYCLE_STAGES = parseBoolOrDefault(raw, Data.VNS_ADAPTIVE_CYCLE_STAGES);
      } else if ("--vnsAdaptiveCycle".equalsIgnoreCase(a) || "-vnsAdaptiveCycle".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          Data.VNS_ADAPTIVE_CYCLE_STAGES = parseBoolOrDefault(args[idx + 1], Data.VNS_ADAPTIVE_CYCLE_STAGES);
          idx++;
        } else {
          Data.VNS_ADAPTIVE_CYCLE_STAGES = true;
        }
      }
 
      if (a != null && a.startsWith("--samples=")) {
        try {
          Data.INITIAL_SAMPLES = Integer.parseInt(a.substring("--samples=".length()).trim());
        } catch (NumberFormatException ignored) {}
      } else if ("--samples".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          try {
            Data.INITIAL_SAMPLES = Integer.parseInt(args[idx + 1].trim());
            idx++;
          } catch (NumberFormatException ignored) {}
        }
      }
 
      if (a != null && a.startsWith("--sampleIncrease=")) {
        String v = a.substring("--sampleIncrease=".length()).trim();
        Data.ENABLE_SAMPLE_INCREASE = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
      } else if ("--sampleIncrease".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          String v = args[idx + 1].trim();
          Data.ENABLE_SAMPLE_INCREASE = "1".equals(v) || "true".equalsIgnoreCase(v) || "yes".equalsIgnoreCase(v);
          idx++;
        } else {
          Data.ENABLE_SAMPLE_INCREASE = true;
        }
      }

      if (a != null && a.startsWith("--topBottomRebalanceCount=")) {
        try {
          Data.TOP_BOTTOM_REBALANCE_COUNT = Integer.parseInt(a.substring("--topBottomRebalanceCount=".length()).trim());
        } catch (NumberFormatException ignored) {}
      } else if ("--topBottomRebalanceCount".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          try {
            Data.TOP_BOTTOM_REBALANCE_COUNT = Integer.parseInt(args[idx + 1].trim());
            idx++;
          } catch (NumberFormatException ignored) {}
        }
      }

      if (a != null && a.startsWith("--maxOuterIterations=")) {
        if (idx + 1 < args.length) {
          try {
            Data.MAX_OUTER_ITERATIONS = Integer.parseInt(a.substring("--maxOuterIterations=".length()).trim());
            idx++;
          } catch (NumberFormatException ignored) {}
        }
      } else if ("--maxOuterIterations".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          try {
            Data.MAX_OUTER_ITERATIONS = Integer.parseInt(args[idx + 1].trim());
            idx++;
          } catch (NumberFormatException ignored) {}
        }
      }

      if (a != null && a.startsWith("--maxVnsShakes=")) {
        try {
          Data.MAX_VNS_SHAKES = Integer.parseInt(a.substring("--maxVnsShakes=".length()).trim());
          Data.STAGE2_MAX_SHAKES = Data.MAX_VNS_SHAKES; // keep legacy mirror synced
        } catch (NumberFormatException ignored) {}
      } else if ("--maxVnsShakes".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length) {
          try {
            Data.MAX_VNS_SHAKES = Integer.parseInt(args[idx + 1].trim());
            Data.STAGE2_MAX_SHAKES = Data.MAX_VNS_SHAKES;
            idx++;
          } catch (NumberFormatException ignored) {}
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnsexitonimprove=")) {
        Data.VNS_EXIT_ON_FIRST_IMPROVEMENT =
            parseBoolOrDefault(a.substring("--vnsexitonimprove=".length()), Data.VNS_EXIT_ON_FIRST_IMPROVEMENT);
      } else if ("--vnsExitOnImprove".equalsIgnoreCase(a) || "-vnsExitOnImprove".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          Data.VNS_EXIT_ON_FIRST_IMPROVEMENT = parseBoolOrDefault(args[idx + 1], Data.VNS_EXIT_ON_FIRST_IMPROVEMENT);
          idx++;
        } else {
          Data.VNS_EXIT_ON_FIRST_IMPROVEMENT = false;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--vnscontinueonimprove=")) {
        boolean continueOnImprove =
            parseBoolOrDefault(a.substring("--vnscontinueonimprove=".length()), !Data.VNS_EXIT_ON_FIRST_IMPROVEMENT);
        Data.VNS_EXIT_ON_FIRST_IMPROVEMENT = !continueOnImprove;
      } else if ("--vnsContinueOnImprove".equalsIgnoreCase(a) || "-vnsContinueOnImprove".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          boolean continueOnImprove = parseBoolOrDefault(args[idx + 1], !Data.VNS_EXIT_ON_FIRST_IMPROVEMENT);
          Data.VNS_EXIT_ON_FIRST_IMPROVEMENT = !continueOnImprove;
          idx++;
        } else {
          Data.VNS_EXIT_ON_FIRST_IMPROVEMENT = false;
        }
      }
      if (a != null && startsWithIgnoreCase(a, "--forcevnsfirstiter=")) {
        Data.FORCE_VNS_ON_FIRST_ITERATION =
            parseBoolOrDefault(a.substring("--forcevnsfirstiter=".length()), Data.FORCE_VNS_ON_FIRST_ITERATION);
      } else if ("--forceVnsFirstIter".equalsIgnoreCase(a) || "-forceVnsFirstIter".equalsIgnoreCase(a)) {
        if (idx + 1 < args.length && args[idx + 1] != null && !args[idx + 1].startsWith("--")) {
          Data.FORCE_VNS_ON_FIRST_ITERATION =
              parseBoolOrDefault(args[idx + 1], Data.FORCE_VNS_ON_FIRST_ITERATION);
          idx++;
        } else {
          Data.FORCE_VNS_ON_FIRST_ITERATION = true;
        }
      }
    }
 
    // Enforce global minimum samples
    if (Data.INITIAL_SAMPLES < Data.MIN_SAMPLES) {
      Data.INITIAL_SAMPLES = Data.MIN_SAMPLES;
    }
 
    if (verbose) {
      System.out.println("INFO: Effective options:");
      System.out.println("- INITIAL_SAMPLES=" + Data.INITIAL_SAMPLES + " (MIN_SAMPLES=" + Data.MIN_SAMPLES + ")");
      System.out.println("- ENABLE_SAMPLE_INCREASE=" + Data.ENABLE_SAMPLE_INCREASE);
      System.out.println("- SAMPLE_MAX=" + Data.SAMPLE_MAX + " SAMPLE_SEARCH_MAX_EVALS=" + Data.SAMPLE_SEARCH_MAX_EVALS);
      System.out.println("- SCHEDULING_MODE=" + Data.SCHEDULING_MODE + " JOB_DISPATCH_RULE=" + Data.JOB_DISPATCH_RULE);
      System.out.println("- ENABLE_ROOM_LOCAL_SEARCH=" + Data.ENABLE_ROOM_LOCAL_SEARCH);
      System.out.println("- FORCE_VNS_ON_FIRST_ITERATION=" + Data.FORCE_VNS_ON_FIRST_ITERATION);
      System.out.println("- RANDOM_SEED=" + (randomSeed == null ? "random" : randomSeed));
    }
 
    if (batchPath != null && !batchPath.isBlank()) {
      if ((batchDetailsDir == null || batchDetailsDir.isBlank()) && (csvFlag || (csvDir != null && !csvDir.isBlank()))) {
        batchDetailsDir = (csvDir == null || csvDir.isBlank()) ? "csv_out" : csvDir;
        batchSchedule = true;
        if (verbose) {
          System.out.println("INFO: Batch mode: using --csv/--csvDir as --batchDetails=" + batchDetailsDir + " and enabling --batchSchedule");
        }
      }
 
      String out = (batchOut == null || batchOut.isBlank()) ? "batch_results.csv" : batchOut;
      try {
        BatchRunner.run(
            Paths.get(batchPath),
            Paths.get(out),
            (batchDetailsDir == null || batchDetailsDir.isBlank()) ? null : Paths.get(batchDetailsDir),
            batchSchedule,
            verbose,
            printScheduleEvals,
            randomSeed
        );
      } catch (IOException e) {
        throw new RuntimeException("Failed to run batch: " + batchPath, e);
      }
      System.out.println("Batch results written to: " + Paths.get(out).toAbsolutePath());
      if (batchDetailsDir != null && !batchDetailsDir.isBlank()) {
        System.out.println("Batch details written to: " + Paths.get(batchDetailsDir).toAbsolutePath());
      }
      return;
    }
 
    Map<Integer, Integer> lastOuterVnsIteration = new HashMap<>();
    int[] globalVnsState = new int[] {0}; // total VNS iterations across all outer iterations
    int[] nextGlobalCheckpoint = new int[] {VNS_PROGRESS_STEP};
    int[] globalBest = new int[] {Integer.MAX_VALUE, Integer.MAX_VALUE}; // lateness, samples
    List<VnsEventRow> vnsEventRows = new ArrayList<>();
    List<VnsCheckpointRow> vnsCheckpointRows = new ArrayList<>();
    HeuristicSolver.ProgressListener listener = new HeuristicSolver.ProgressListener() {
      @Override
      public void onOuterIterationLocalResult(
          int outerIteration,
          int totalLateness,
          int totalSamples,
          long stage1RuntimeMs,
          long stage2RuntimeMs,
          int stage2Passes,
          int stage2Evals
      ) {
        if (totalLateness < globalBest[0] || (totalLateness == globalBest[0] && totalSamples < globalBest[1])) {
          globalBest[0] = totalLateness;
          globalBest[1] = totalSamples;
        }
        System.out.println(
            "OUTER_LOCAL iter=" + outerIteration +
                " totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " stage1Ms=" + stage1RuntimeMs +
                " stage2Ms=" + stage2RuntimeMs +
                " stage2Passes=" + stage2Passes +
                " stage2Evals=" + stage2Evals +
                " globalBestLateness=" + globalBest[0] +
                " globalBestSamples=" + globalBest[1]
        );
      }

      @Override
      public void onStage2PreShake(int outerIteration, int totalLateness, int totalSamples, long runtimeMs) {
        if (totalLateness < globalBest[0] || (totalLateness == globalBest[0] && totalSamples < globalBest[1])) {
          globalBest[0] = totalLateness;
          globalBest[1] = totalSamples;
        }
        vnsEventRows.add(new VnsEventRow(
            globalVnsState[0],
            outerIteration,
            0,
            "PRE_SHAKE",
            "PRESHAKE",
            -1.0,
            totalLateness,
            totalSamples,
            runtimeMs,
            globalBest[0],
            globalBest[1]
        ));
        System.out.println(
            "VNS event: outerIter=" + outerIteration +
                " type=PRE_SHAKE" +
                " globalVnsIter=" + globalVnsState[0] +
                " totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " stage2ElapsedMs=" + runtimeMs
        );
      }

      @Override
      public void onVnsIteration(
          int outerIteration,
          int vnsIteration,
          String kind,
          int totalLateness,
          int totalSamples,
          long stage2ElapsedMs,
          double shakeRatio
      ) {
        int prevOuterVns = lastOuterVnsIteration.getOrDefault(outerIteration, 0);
        int delta = Math.max(0, vnsIteration - prevOuterVns);
        lastOuterVnsIteration.put(outerIteration, vnsIteration);
        globalVnsState[0] += delta;

        if (totalLateness < globalBest[0] || (totalLateness == globalBest[0] && totalSamples < globalBest[1])) {
          globalBest[0] = totalLateness;
          globalBest[1] = totalSamples;
        }

        vnsEventRows.add(new VnsEventRow(
            globalVnsState[0],
            outerIteration,
            vnsIteration,
            "SHAKE",
            kind,
            shakeRatio,
            totalLateness,
            totalSamples,
            stage2ElapsedMs,
            globalBest[0],
            globalBest[1]
        ));
        System.out.println(
            "VNS event: outerIter=" + outerIteration +
                " outerVnsIter=" + vnsIteration +
                " globalVnsIter=" + globalVnsState[0] +
                " kind=" + kind +
                " ratio=" + String.format(Locale.ROOT, "%.3f", shakeRatio) +
                " totalLateness=" + totalLateness +
                " totalSamples=" + totalSamples +
                " stage2ElapsedMs=" + stage2ElapsedMs
        );

        while (globalVnsState[0] >= nextGlobalCheckpoint[0]) {
          VnsCheckpointRow row = new VnsCheckpointRow(
              nextGlobalCheckpoint[0],
              globalVnsState[0],
              outerIteration,
              vnsIteration,
              globalBest[0],
              globalBest[1],
              totalLateness,
              totalSamples,
              stage2ElapsedMs,
              kind,
              shakeRatio
          );
          vnsCheckpointRows.add(row);
          System.out.println(
              "VNS checkpoint(global): vnsIter=" + nextGlobalCheckpoint[0] +
                  " globalBestTotalLateness=" + globalBest[0] +
                  " globalBestTotalSamples=" + globalBest[1] +
                  " outerIter=" + outerIteration +
                  " outerVnsIter=" + vnsIteration +
                  " currentTotalLateness=" + totalLateness +
                  " currentTotalSamples=" + totalSamples +
                  " stage2ElapsedMs=" + stage2ElapsedMs +
                  " lastShake=" + kind +
                  " ratio=" + String.format(Locale.ROOT, "%.3f", shakeRatio)
          );
          nextGlobalCheckpoint[0] += VNS_PROGRESS_STEP;
        }
      }
    };

    HeuristicSolver solver = buildSolver(verbose, listener, randomSeed);
    long solveT0 = System.currentTimeMillis();
    List<Solution> sols = solver.solve();
    long solveT1 = System.currentTimeMillis();
    long scheduleEvals = solver.getScheduleEvalCount();
 
    Solution best = sols.stream().min(Comparator.comparingInt(s -> s.totalLateness)).orElseThrow();
    int bestLateProjects = countLateProjects(best);
 
    System.out.println("====================");
    System.out.println("OUTER ITERATION TRACE");
    for (Solution s : sols) {
      System.out.println(
          "OUTER event: iter=" + s.iteration +
              " totalLateness=" + s.totalLateness +
              " lateProjects=" + countLateProjects(s) +
              " totalSamples=" + totalSamples(s.projects) +
              " stage1Ms=" + s.stage1RuntimeMs +
              " stage2Ms=" + s.stage2RuntimeMs +
              " stage2Shakes=" + s.stage2Shakes +
              " stage2VnsMs=" + s.stage2VnsRuntimeMs
      );
    }
    System.out.println();

    for (Solution s : sols) {
      printSolution(s);
      System.out.println();
    }
 
    System.out.println("TOTAL runtimeMs = " + (solveT1 - solveT0));
    if (printScheduleEvals) {
      System.out.println("TOTAL scheduleEvals = " + scheduleEvals);
    }
 
    System.out.println("====================");
    System.out.println("BEST (min total lateness): iter=" + best.iteration +
        " totalLateness=" + best.totalLateness +
        " lateProjects=" + bestLateProjects);
    System.out.println("BEST Stage1 (setpoints) runtimeMs = " + best.stage1RuntimeMs);
 
    if (best.stage2PreShakeTotalLateness >= 0) {
      System.out.println("BEST Stage2 pre-shake: totalLateness=" + best.stage2PreShakeTotalLateness +
          " totalSamples=" + best.stage2PreShakeTotalSamples +
          " runtimeMs=" + best.stage2PreShakeRuntimeMs +
          " didShake=" + best.stage2DidShake);
    }
    if (best.stage2RuntimeMs >= 0) {
      System.out.println("BEST Stage2 runtimeMs = " + best.stage2RuntimeMs +
          " (passes=" + best.stage2Passes +
          ", evals=" + best.stage2Evals +
          ", shakes=" + best.stage2Shakes +
          ", vnsRuntimeMs=" + best.stage2VnsRuntimeMs + ")");
    }
 
    if (dumpProjectId != null && !dumpProjectId.isBlank()) {
      dumpProject(best, dumpProjectId);
    }
 
    if (dumpFirst10) {
      dumpFirstNProjects(best, 10);
    }
 
    if ((csvDir != null && !csvDir.isBlank()) || csvFlag) {
      if (csvDir == null || csvDir.isBlank()) csvDir = "csv_out";
      try {
        int rows = exportCsv(sols, best, Paths.get(csvDir), vnsCheckpointRows, vnsEventRows);
        System.out.println();
        System.out.println("CSV exported to: " + Paths.get(csvDir).toAbsolutePath());
        System.out.println("- outer_iterations.csv");
        System.out.println("- schedule_by_project.csv");
        System.out.println("- schedule_by_station.csv");
        System.out.println("- vns_events.csv");
        System.out.println("- vns_checkpoints.csv");
        System.out.println("Rows written: " + rows);
      } catch (IOException e) {
        throw new RuntimeException("Failed to export CSV to dir=" + csvDir, e);
      }
    }
 
    if (diagnose) {
      printDiagnostics(best);
    }
  }
 
  private static int countLateProjects(Solution s) {
    int c = 0;
    for (ProjectResult r : s.results) {
      if (r.lateness > 0) c++;
    }
    return c;
  }
 
  private static void printHelp() {
    System.out.println("Heuristic scheduler (job-based EDD + room assignment)");
    System.out.println();
    System.out.println("Usage:");
    System.out.println("  java -cp <classes> tr.testodasi.heuristic.Main [options]");
    System.out.println();
    System.out.println("Options:");
    System.out.println("  -h, --help                 Show this help and exit");
    System.out.println("  -v, --verbose              Print effective options + extra logs");
    System.out.println("  --batch <instances.csv>    Run multiple instances and write one summary CSV");
    System.out.println("  --batchOut <out.csv>       Output path for batch summary (default: batch_results.csv)");
    System.out.println("  --batchDetails <dir>       Write detailed CSVs into <dir> (project results, chamber env)");
    System.out.println("  --batchSchedule            (with --batchDetails) also write full schedule rows (can be large)");
    System.out.println("  --dumpProject=P17          Dump detailed schedule for one project id");
    System.out.println("  --dumpFirst10              Dump detailed schedule for P1..P10");
    System.out.println("  --diagnose, --diag         Print capacity/workload diagnostics");
    System.out.println("  --scheduleEvals            Print schedule evaluation count");
    System.out.println();
    System.out.println("  --csv                      Export CSV to ./csv_out");
    System.out.println("  --csvDir <dir>             Export CSV to <dir> (creates dir if missing)");
    System.out.println("  --csvDir=<dir>             Same as above");
    System.out.println("  --csv=<dir>                Same as above");
    System.out.println("                            NOTE: In batch mode, --csv/--csvDir act as a shortcut for:");
    System.out.println("                                  --batchDetails <dir> --batchSchedule");
    System.out.println();
    System.out.println("Tuning flags (booleans accept: 1/true/yes):");
    System.out.println("  --samples=<n>              Initial samples per project (min=" + Data.MIN_SAMPLES + ")");
    System.out.println("  --samples <n>              Same as above");
    System.out.println("  --sampleIncrease           Enable sample local-search (same as true)");
    System.out.println("  --sampleIncrease <bool>    Enable/disable sample local-search");
    System.out.println("  --sampleIncrease=<bool>    Enable/disable sample local-search");
    System.out.println("  (Stage2 flow is fixed in this build: +1/+2/-1/-2 local search, top/bottom rebalance, then VNS-on-stall)");
    System.out.println();
    System.out.println("  --roomLS=<bool>            Enable/disable room local-search");
    System.out.println("  --roomLSMaxEvals=<n>       Room local-search evaluation budget");
    System.out.println("  --roomLSSwap=<bool>        Enable/disable swap neighbors");
    System.out.println("  --roomLSMove=<bool>        Enable/disable move neighbors");
    System.out.println("  --roomLSIncludeSample=<bool>  Score rooms using sample-heuristic too (slower)");
    System.out.println("  --seed=<n|random>          RNG seed (default=42, use random for non-deterministic runs)");
    System.out.println("  --vnsMode=<down|up|both>   VNS shake direction mode (default: both)");
    System.out.println("  --vnsStrategy=<normal|adaptive>  VNS shake ratio strategy (default: adaptive)");
    System.out.println("  --vnsShakeRatio=<x>        Fixed shake ratio in normal mode (default: 0.30)");
    System.out.println("  --vnsAdaptiveStage1Ratio=<x>   Adaptive stage-1 ratio (default: 0.20)");
    System.out.println("  --vnsAdaptiveStage2Ratio=<x>   Adaptive stage-2 ratio (default: 0.30)");
    System.out.println("  --vnsAdaptiveStage3Ratio=<x>   Adaptive stage-3 ratio (default: 0.40)");
    System.out.println("  --vnsAdaptiveStage1Shakes=<n>  Adaptive stage-1 shake count (default: 15)");
    System.out.println("  --vnsAdaptiveStage2Shakes=<n>  Adaptive stage-2 shake count (default: 15)");
    System.out.println("  --vnsAdaptiveStage3Shakes=<n>  Adaptive stage-3 target shakes (default: 25)");
    System.out.println("  --vnsAdaptiveCycle=<bool>      Cycle ratios as 1->2->3->1... (default: false)");
    System.out.println("  -vnsAdaptiveCycle=<bool>       Alias for --vnsAdaptiveCycle");
    System.out.println("  --vnsFallbackOnNoImprove=<bool>  Retry VNS with next fixed ratio on no-improve (default: false)");
    System.out.println("  --vnsFallbackRatios=a,b,c      Fallback fixed ratios sequence (default: 0.10,0.20,0.30)");
    System.out.println("  --vnsExitOnImprove=<bool>   Exit VNS immediately on first improvement (default: false)");
    System.out.println("  --vnsContinueOnImprove=<bool> Inverse of vnsExitOnImprove (true => no early exit)");
    System.out.println("  --forceVnsFirstIter=<bool>  Force VNS entry in first outer iteration (default: false)");
    System.out.println();
    System.out.println("  --validate=<bool>          Enable/disable schedule validation");
    System.out.println();
    System.out.println("Examples:");
    System.out.println("  java -cp out tr.testodasi.heuristic.Main --verbose --csv");
    System.out.println("  java -cp out tr.testodasi.heuristic.Main --dumpProject=P1 --csvDir=csv_out");
  }
 
  private static void printSolution(Solution s) {
    System.out.println("====================");
    System.out.println("ITERATION " + s.iteration);
    System.out.println("Total lateness = " + s.totalLateness);
    System.out.println("Late projects = " + countLateProjects(s));
    System.out.println("Stage1 (setpoints) runtimeMs = " + s.stage1RuntimeMs);
 
    if (s.stage2PreShakeTotalLateness >= 0) {
      System.out.println("Stage2 pre-shake total lateness = " + s.stage2PreShakeTotalLateness +
          " (totalSamples=" + s.stage2PreShakeTotalSamples +
          ", runtimeMs=" + s.stage2PreShakeRuntimeMs +
          ", didShake=" + s.stage2DidShake + ")");
    }
    if (s.stage2RuntimeMs >= 0) {
      System.out.println("Stage2 runtimeMs = " + s.stage2RuntimeMs +
          " (passes=" + s.stage2Passes +
          ", evals=" + s.stage2Evals +
          ", shakes=" + s.stage2Shakes +
          ", vnsRuntimeMs=" + s.stage2VnsRuntimeMs + ")");
    }
 
    System.out.println("\nChamber setpoints (for this iteration):");
    for (var c : Data.CHAMBERS) {
      Env env = s.chamberEnv.get(c.id);
      System.out.println("- " + c.id + " stations=" + c.stations + " volt=" + c.voltageCapable + " humAdj=" + c.humidityAdjustable + " => " + env);
    }
 
    System.out.println("\nProject sample counts:");
    s.projects.stream()
        .sorted(Comparator.comparing(p -> p.id))
        .forEach(p -> System.out.println("- " + p.id + " samples=" + p.samples + " due=" + p.dueDateDays + " needsVolt=" + p.needsVoltage));
 
    System.out.println("\nProject results:");
    s.results.stream()
        .sorted(Comparator.comparing(r -> r.projectId))
        .forEach(r -> System.out.println("- " + r.projectId + " completion=" + r.completionDay + " due=" + r.dueDate + " lateness=" + r.lateness));
  }
 
  private static void dumpProject(Solution sol, String projectId) {
    Objects.requireNonNull(sol);
    Objects.requireNonNull(projectId);
    System.out.println();
    System.out.println("====================");
    System.out.println("SCHEDULE DUMP for " + projectId + " (iter=" + sol.iteration + ")");
    sol.schedule.stream()
        .filter(j -> projectId.equals(j.projectId))
        .sorted(Comparator.comparingInt((Scheduler.ScheduledJob j) -> j.start).thenComparing(j -> j.testId))
        .forEach(j -> System.out.println(
            j.testId + " " + j.env +
                " sample=" + j.sampleIdx +
                " " + j.chamberId + "[st" + j.stationIdx + "]" +
                " start=" + j.start + " end=" + j.end
        ));
  }
 
  private static void dumpFirstNProjects(Solution sol, int n) {
    Objects.requireNonNull(sol);
    if (n <= 0) return;
 
    Set<String> wanted = new TreeSet<>((a, b) -> Integer.compare(parseProjectNum(a), parseProjectNum(b)));
    for (int i = 1; i <= n; i++) wanted.add("P" + i);
 
    System.out.println();
    System.out.println("====================");
    System.out.println("FIRST " + n + " PROJECTS - DETAILED SCHEDULE (iter=" + sol.iteration + ")");
 
    for (String pid : wanted) {
      System.out.println();
      System.out.println("---- " + pid + " ----");
      sol.schedule.stream()
          .filter(j -> pid.equals(j.projectId))
          .sorted(Comparator.comparingInt((Scheduler.ScheduledJob j) -> j.start).thenComparing(j -> j.testId))
          .forEach(j -> System.out.println(
              j.testId +
                  " env=" + j.env +
                  " sample=" + j.sampleIdx +
                  " room=" + j.chamberId +
                  " station=" + j.stationIdx +
                  " start=" + j.start +
                  " end=" + j.end
          ));
    }
  }
 
  private static int parseProjectNum(String pid) {
    if (pid == null) return Integer.MAX_VALUE;
    if (!pid.startsWith("P")) return Integer.MAX_VALUE;
    try {
      return Integer.parseInt(pid.substring(1));
    } catch (NumberFormatException e) {
      return Integer.MAX_VALUE;
    }
  }
 
  private static int exportCsv(
      List<Solution> sols,
      Solution sol,
      Path dir,
      List<VnsCheckpointRow> vnsCheckpoints,
      List<VnsEventRow> vnsEvents
  ) throws IOException {
    Objects.requireNonNull(sols);
    Objects.requireNonNull(sol);
    Objects.requireNonNull(dir);
    Objects.requireNonNull(vnsCheckpoints);
    Objects.requireNonNull(vnsEvents);
    Files.createDirectories(dir);
 
    Path outerIterationsPath = dir.resolve("outer_iterations.csv");
    try (BufferedWriter w = Files.newBufferedWriter(outerIterationsPath)) {
      w.write("iteration,totalLateness,lateProjects,totalSamples,stage1RuntimeMs,stage2PreShakeTotalLateness,stage2PreShakeTotalSamples,stage2PreShakeRuntimeMs,stage2DidShake,stage2RuntimeMs,stage2Passes,stage2Evals,stage2Shakes,stage2VnsRuntimeMs");
      w.newLine();
      sols.stream()
          .sorted(Comparator.comparingInt(s -> s.iteration))
          .forEach(s -> {
            try {
              w.write(
                  s.iteration + "," +
                      s.totalLateness + "," +
                      countLateProjects(s) + "," +
                      totalSamples(s.projects) + "," +
                      s.stage1RuntimeMs + "," +
                      s.stage2PreShakeTotalLateness + "," +
                      s.stage2PreShakeTotalSamples + "," +
                      s.stage2PreShakeRuntimeMs + "," +
                      s.stage2DidShake + "," +
                      s.stage2RuntimeMs + "," +
                      s.stage2Passes + "," +
                      s.stage2Evals + "," +
                      s.stage2Shakes + "," +
                      s.stage2VnsRuntimeMs
              );
              w.newLine();
            } catch (IOException e) {
              throw new RuntimeException(e);
            }
          });
    }

    Map<String, Project> projectById = new HashMap<>();
    for (Project p : sol.projects) projectById.put(p.id, p);
 
    Path byProject = dir.resolve("schedule_by_project.csv");
    try (BufferedWriter w = Files.newBufferedWriter(byProject)) {
      w.write("iteration,projectId,testId,category,tempC,humidity,durationDays,needsVoltage,dueDateDays,samples,sampleIdx,chamberId,stationIdx,startDay,endDay");
      w.newLine();
      sol.schedule.stream()
          .sorted(Comparator.comparing((Scheduler.ScheduledJob j) -> j.projectId)
              .thenComparingInt(j -> j.start)
              .thenComparing(j -> j.testId))
          .forEach(j -> writeRow(w, sol.iteration, j, projectById.get(j.projectId)));
    }
 
    Path byStation = dir.resolve("schedule_by_station.csv");
    try (BufferedWriter w = Files.newBufferedWriter(byStation)) {
      w.write("iteration,chamberId,stationIdx,startDay,endDay,projectId,testId,category,tempC,humidity,durationDays,needsVoltage,dueDateDays,samples,sampleIdx");
      w.newLine();
      sol.schedule.stream()
          .sorted(Comparator.comparing((Scheduler.ScheduledJob j) -> j.chamberId)
              .thenComparingInt(j -> j.stationIdx)
              .thenComparingInt(j -> j.start)
              .thenComparing(j -> j.projectId)
              .thenComparing(j -> j.testId))
          .forEach(j -> writeRowStation(w, sol.iteration, j, projectById.get(j.projectId)));
    }

    Path vnsEventsPath = dir.resolve("vns_events.csv");
    try (BufferedWriter w = Files.newBufferedWriter(vnsEventsPath)) {
      w.write("globalVnsIterationAtEvent,outerIteration,outerVnsIteration,eventType,shakeKind,shakeRatio,currentTotalLateness,currentTotalSamples,stage2ElapsedMs,globalBestTotalLateness,globalBestTotalSamples");
      w.newLine();
      for (VnsEventRow e : vnsEvents) {
        w.write(
            e.globalVnsIterationAtEvent + "," +
                e.outerIteration + "," +
                e.outerVnsIteration + "," +
                e.eventType + "," +
                (e.shakeKind == null ? "" : e.shakeKind) + "," +
                String.format(Locale.ROOT, "%.6f", e.shakeRatio) + "," +
                e.currentTotalLateness + "," +
                e.currentTotalSamples + "," +
                e.stage2ElapsedMs + "," +
                e.globalBestTotalLateness + "," +
                e.globalBestTotalSamples
        );
        w.newLine();
      }
    }

    Path vnsCheckpointsPath = dir.resolve("vns_checkpoints.csv");
    try (BufferedWriter w = Files.newBufferedWriter(vnsCheckpointsPath)) {
      w.write("checkpointGlobalVnsIteration,globalVnsIterationAtEvent,outerIteration,outerVnsIteration,globalBestTotalLateness,globalBestTotalSamples,currentTotalLateness,currentTotalSamples,stage2ElapsedMs,lastShakeKind,shakeRatio");
      w.newLine();
      vnsCheckpoints.stream()
          .sorted(Comparator.comparingInt((VnsCheckpointRow r) -> r.checkpointGlobalVnsIteration))
          .forEach(r -> {
            try {
              w.write(
                  r.checkpointGlobalVnsIteration + "," +
                      r.globalVnsIterationAtEvent + "," +
                      r.outerIteration + "," +
                      r.outerVnsIteration + "," +
                      r.globalBestTotalLateness + "," +
                      r.globalBestTotalSamples + "," +
                      r.currentTotalLateness + "," +
                      r.currentTotalSamples + "," +
                      r.stage2ElapsedMs + "," +
                      (r.lastShakeKind == null ? "" : r.lastShakeKind) + "," +
                      String.format(Locale.ROOT, "%.6f", r.shakeRatio)
              );
              w.newLine();
            } catch (IOException e) {
              throw new RuntimeException(e);
            }
          });
    }
 
    return sol.schedule.size();
  }

  private static int totalSamples(List<Project> projects) {
    int sum = 0;
    for (Project p : projects) sum += p.samples;
    return sum;
  }
 
  private static void writeRow(BufferedWriter w, int iteration, Scheduler.ScheduledJob j, Project p) {
    try {
      w.write(iteration + "," + j.projectId + "," + j.testId + "," + j.category + "," +
          j.env.temperatureC + "," + j.env.humidity + "," + j.durationDays + "," +
          (p != null && p.needsVoltage) + "," + (p != null ? p.dueDateDays : "") + "," + (p != null ? p.samples : "") + "," +
          j.sampleIdx + "," + j.chamberId + "," + j.stationIdx + "," + j.start + "," + j.end);
      w.newLine();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
 
  private static void writeRowStation(BufferedWriter w, int iteration, Scheduler.ScheduledJob j, Project p) {
    try {
      w.write(iteration + "," + j.chamberId + "," + j.stationIdx + "," + j.start + "," + j.end + "," +
          j.projectId + "," + j.testId + "," + j.category + "," +
          j.env.temperatureC + "," + j.env.humidity + "," + j.durationDays + "," +
          (p != null && p.needsVoltage) + "," + (p != null ? p.dueDateDays : "") + "," + (p != null ? p.samples : "") + "," +
          j.sampleIdx);
      w.newLine();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
 
  private static boolean startsWithIgnoreCase(String s, String prefix) {
    if (s == null || prefix == null) return false;
    if (s.length() < prefix.length()) return false;
    return s.regionMatches(true, 0, prefix, 0, prefix.length());
  }

  private static Long parseSeedArg(String raw, Long current) {
    if (raw == null) return current;
    String v = raw.trim();
    if (v.isEmpty()) return current;
    if ("random".equalsIgnoreCase(v) || "none".equalsIgnoreCase(v) || "null".equalsIgnoreCase(v)) {
      return null;
    }
    try {
      return Long.parseLong(v);
    } catch (NumberFormatException ignored) {
      return current;
    }
  }

  private static Data.VnsMode parseVnsModeArg(String raw, Data.VnsMode current) {
    if (raw == null) return current;
    String v = raw.trim().toLowerCase(Locale.ROOT);
    if (v.isEmpty()) return current;
    return switch (v) {
      case "down", "down_only", "only_down" -> Data.VnsMode.DOWN_ONLY;
      case "up", "up_only", "only_up" -> Data.VnsMode.UP_ONLY;
      case "both", "up_down", "updown" -> Data.VnsMode.BOTH;
      default -> current;
    };
  }

  private static Data.VnsStrategy parseVnsStrategyArg(String raw, Data.VnsStrategy current) {
    if (raw == null) return current;
    String v = raw.trim().toLowerCase(Locale.ROOT);
    if (v.isEmpty()) return current;
    return switch (v) {
      case "normal", "fixed" -> Data.VnsStrategy.NORMAL;
      case "adaptive" -> Data.VnsStrategy.ADAPTIVE;
      default -> current;
    };
  }

  private static double parseDoubleOrDefault(String raw, double current) {
    if (raw == null) return current;
    String v = raw.trim();
    if (v.isEmpty()) return current;
    try {
      return Double.parseDouble(v);
    } catch (NumberFormatException ignored) {
      return current;
    }
  }

  private static double[] parseDoubleArrayOrDefault(String raw, double[] current) {
    if (raw == null) return current;
    String v = raw.trim();
    if (v.isEmpty()) return current;
    String[] parts = v.split(",");
    List<Double> out = new ArrayList<>();
    for (String p : parts) {
      String t = p == null ? "" : p.trim();
      if (t.isEmpty()) continue;
      try {
        out.add(Double.parseDouble(t));
      } catch (NumberFormatException ignored) {
        return current;
      }
    }
    if (out.isEmpty()) return current;
    double[] arr = new double[out.size()];
    for (int i = 0; i < out.size(); i++) {
      arr[i] = out.get(i);
    }
    return arr;
  }

  private static int parseIntOrDefault(String raw, int current) {
    if (raw == null) return current;
    String v = raw.trim();
    if (v.isEmpty()) return current;
    try {
      return Integer.parseInt(v);
    } catch (NumberFormatException ignored) {
      return current;
    }
  }

  private static boolean parseBoolOrDefault(String raw, boolean current) {
    if (raw == null) return current;
    String v = raw.trim().toLowerCase(Locale.ROOT);
    if (v.isEmpty()) return current;
    if ("1".equals(v) || "true".equals(v) || "yes".equals(v) || "y".equals(v)) return true;
    if ("0".equals(v) || "false".equals(v) || "no".equals(v) || "n".equals(v)) return false;
    return current;
  }

  private static HeuristicSolver buildSolver(
      boolean verbose,
      HeuristicSolver.ProgressListener listener,
      Long randomSeed
  ) {
    try {
      return HeuristicSolver.class
          .getConstructor(boolean.class, HeuristicSolver.ProgressListener.class, Long.class)
          .newInstance(verbose, listener, randomSeed);
    } catch (ReflectiveOperationException ignored) {
      // Backward compatibility: older solver versions only have (boolean, listener) constructor.
      return new HeuristicSolver(verbose, listener);
    }
  }
 
  private static void printDiagnostics(Solution best) {
    System.out.println();
    System.out.println("====================");
    System.out.println("DIAGNOSTICS");
 
    Map<Env, Integer> stationsByEnv = new HashMap<>();
    for (ChamberSpec c : Data.CHAMBERS) {
      Env env = best.chamberEnv.get(c.id);
      if (env == null) continue;
      stationsByEnv.merge(env, c.stations, Integer::sum);
    }
 
    Map<Env, Long> workByEnv = new HashMap<>();
    for (Project p : best.projects) {
      for (int ti = 0; ti < Data.TESTS.size(); ti++) {
        if (!p.required[ti]) continue;
        TestDef t = Data.TESTS.get(ti);
        int jobs = 1;
        if (t.category == TestCategory.PULLDOWN) jobs = p.samples;
        workByEnv.merge(t.env, (long) jobs * t.durationDays, Long::sum);
      }
    }
 
    System.out.println("ENV workload / station:");
    workByEnv.entrySet().stream()
        .sorted((a, b) -> {
          double ra = a.getValue() / (stationsByEnv.getOrDefault(a.getKey(), 1) * 1.0);
          double rb = b.getValue() / (stationsByEnv.getOrDefault(b.getKey(), 1) * 1.0);
          return Double.compare(rb, ra);
        })
        .forEach(e -> {
          int cap = stationsByEnv.getOrDefault(e.getKey(), 0);
          double ratio = cap == 0 ? Double.POSITIVE_INFINITY : (e.getValue() / (double) cap);
          System.out.println("- " + e.getKey() + " workDays=" + e.getValue() + " stations=" + cap + " workDaysPerStation=" + String.format("%.2f", ratio));
        });
  }
 
  private static String fmt(double x) {
    return String.format(Locale.ROOT, "%.4f", x);
  }
}